import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import { useEffect } from "react";

interface BackToTerminalButtonProps {
  className?: string;
}

export default function BackToTerminalButton({ className = "" }: BackToTerminalButtonProps) {
  const [, setLocation] = useLocation();

  // Handle Escape key to go back
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setLocation("/");
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [setLocation]);

  return (
    <Button
      onClick={() => setLocation("/")}
      variant="outline"
      size="sm"
      className={`gap-2 ${className}`}
      title="Back to Terminal (Esc)"
    >
      <ArrowLeft className="h-4 w-4" />
      Back to Terminal
    </Button>
  );
}
