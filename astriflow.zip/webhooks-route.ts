import { Router, Request, Response, raw } from "express";
import { processIncomingLead, verifyWebhookSignature, handleWebhookChallenge } from "./webhooks";

const webhookRouter = Router();

/**
 * Instagram/DM Webhook Endpoint
 * POST /api/webhooks/instagram
 *
 * Receives incoming leads from Instagram DM
 */
webhookRouter.post("/instagram", raw({ type: "application/json" }), async (req: Request, res: Response) => {
  try {
    const body = typeof req.body === "string" ? req.body : JSON.stringify(req.body);
    const signature = req.headers["x-hub-signature-256"] as string;

    // Verify webhook signature
    const secret = process.env.INSTAGRAM_WEBHOOK_SECRET || "astriflow_webhook_secret";
    if (signature && !verifyWebhookSignature(body, signature, secret)) {
      console.warn("[Webhook] Invalid signature");
      return res.status(401).json({ error: "Invalid signature" });
    }

    const payload = JSON.parse(body);

    // Handle webhook challenge
    if (payload.challenge) {
      const challenge = handleWebhookChallenge(payload.mode, payload.token, payload.challenge);
      if (challenge) {
        return res.status(200).send(challenge);
      }
      return res.status(403).json({ error: "Invalid challenge" });
    }

    // Process incoming lead
    const leadData = {
      tenantId: parseInt(payload.tenantId || "0"),
      name: payload.name,
      email: payload.email,
      phone: payload.phone,
      message: payload.message,
      source: "instagram_dm" as const,
      externalId: payload.messageId,
      timestamp: payload.timestamp,
    };

    if (!leadData.tenantId) {
      return res.status(400).json({ error: "tenantId is required" });
    }

    const result = await processIncomingLead(leadData);

    if (result.success) {
      res.status(200).json({
        success: true,
        leadId: result.leadId,
        category: result.category,
      });
    } else {
      res.status(400).json({
        success: false,
        error: result.error,
      });
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error("[Webhook] Error processing Instagram webhook:", errorMessage);
    res.status(500).json({
      success: false,
      error: errorMessage,
    });
  }
});

/**
 * Generic Lead Ingestion Webhook
 * POST /api/webhooks/leads
 *
 * Accepts leads from any source (email, API, form submission, etc.)
 */
webhookRouter.post("/leads", async (req: Request, res: Response) => {
  try {
    const { tenantId, name, email, phone, message, source, externalId } = req.body;

    if (!tenantId || !message) {
      return res.status(400).json({
        error: "tenantId and message are required",
      });
    }

    const result = await processIncomingLead({
      tenantId,
      name,
      email,
      phone,
      message,
      source: source || "api",
      externalId,
    });

    if (result.success) {
      res.status(200).json({
        success: true,
        leadId: result.leadId,
        category: result.category,
      });
    } else {
      res.status(400).json({
        success: false,
        error: result.error,
      });
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error("[Webhook] Error processing lead:", errorMessage);
    res.status(500).json({
      success: false,
      error: errorMessage,
    });
  }
});

/**
 * Health check endpoint
 * GET /api/webhooks/health
 */
webhookRouter.get("/health", (req: Request, res: Response) => {
  res.status(200).json({
    status: "ok",
    timestamp: new Date().toISOString(),
  });
});

export default webhookRouter;
