ALTER TABLE `tenants` ADD `status` enum('active','paused','tombstone') DEFAULT 'active';--> statement-breakpoint
ALTER TABLE `tenants` ADD `tombstonedAt` timestamp;--> statement-breakpoint
ALTER TABLE `tenants` ADD `permanentDeleteAt` timestamp;