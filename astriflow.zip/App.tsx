import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import ASTRIflowLogin from "./pages/ASTRIflowLogin";
import MasterAdminDashboard from "./pages/MasterAdminDashboard";
import TenantDashboard from "./pages/TenantDashboard";
import TenantOwnerDashboard from "./pages/TenantOwnerDashboard";
import EmployeeWatcherDashboard from "./pages/EmployeeWatcherDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import Legal from "./pages/Legal";
import CommandCenter from "./pages/CommandCenter";
import OwnerTerminal from "./pages/OwnerTerminal";
import AetherTerminal from "./pages/AetherTerminal";
import VerificationDashboard from "./pages/VerificationDashboard";
import GlobalCommandCenter from "./pages/GlobalCommandCenter";
import StaffOperationsCenter from "./pages/StaffOperationsCenter";
import { useAuth } from "./_core/hooks/useAuth";

function Router() {
  const { user, loading } = useAuth();
  const PRIMARY_OWNER_EMAIL = import.meta.env.VITE_PRIMARY_OWNER_EMAIL || "astriflowsystems@gmail.com";

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          <p className="text-foreground mt-4 font-medium">Loading...</p>
        </div>
      </div>
    );
  }

  // Role-based routing
  if (!user) {
    return (
      <Switch>
        <Route path="/" component={ASTRIflowLogin} />
        <Route path="/legal" component={Legal} />
        <Route component={ASTRIflowLogin} />
      </Switch>
    );
  }

  // Gmail-based owner routing: if email matches PRIMARY_OWNER_EMAIL, route to Owner Terminal
  if (user.email === PRIMARY_OWNER_EMAIL) {
    return (
      <Switch>
        <Route path="/" component={AetherTerminal} />
        <Route path="/aether-terminal" component={AetherTerminal} />
        <Route path="/verification" component={VerificationDashboard} />
        <Route path="/owner-terminal" component={OwnerTerminal} />
        <Route path="/command-center" component={CommandCenter} />
        <Route path="/master-admin" component={MasterAdminDashboard} />
        <Route path="/tenant" component={TenantDashboard} />
        <Route path="/legal" component={Legal} />
        <Route path="/404" component={NotFound} />
        <Route component={AetherTerminal} />
      </Switch>
    );
  }

  // Master Admin (non-owner staff)
  if (user.role === "master_admin") {
    return (
      <Switch>
        <Route path="/" component={StaffOperationsCenter} />
        <Route path="/staff-operations" component={StaffOperationsCenter} />
        <Route path="/admin" component={AdminDashboard} />
        <Route path="/legal" component={Legal} />
        <Route path="/404" component={NotFound} />
        <Route component={StaffOperationsCenter} />
      </Switch>
    );
  }

  // Tenant Admin
  if (user.role === "tenant_admin") {
    return (
      <Switch>
        <Route path="/" component={TenantOwnerDashboard} />
        <Route path="/tenant" component={TenantOwnerDashboard} />
        <Route path="/legal" component={Legal} />
        <Route path="/404" component={NotFound} />
        <Route component={TenantOwnerDashboard} />
      </Switch>
    );
  }

  // Staff/Admin (tenant_user role used for staff)
  if (user.role === "tenant_user") {
    return (
      <Switch>
        <Route path="/" component={StaffOperationsCenter} />
        <Route path="/staff-operations" component={StaffOperationsCenter} />
        <Route path="/admin" component={AdminDashboard} />
        <Route path="/watcher" component={EmployeeWatcherDashboard} />
        <Route path="/legal" component={Legal} />
        <Route path="/404" component={NotFound} />
        <Route component={StaffOperationsCenter} />
      </Switch>
    );
  }

  // Default user
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={Home} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
