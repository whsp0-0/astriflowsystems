import { useEffect, useState } from "react";

const PIN_SESSION_KEY = "astriflow_pin_verified";
const PIN_SESSION_TIMESTAMP = "astriflow_pin_timestamp";
const SESSION_DURATION_MS = 12 * 60 * 60 * 1000; // 12 hours

export function usePINSession() {
  const [isVerified, setIsVerified] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Check if session is still valid on mount
  useEffect(() => {
    const checkSession = () => {
      const verified = localStorage.getItem(PIN_SESSION_KEY);
      const timestamp = localStorage.getItem(PIN_SESSION_TIMESTAMP);

      if (verified && timestamp) {
        const sessionTime = parseInt(timestamp, 10);
        const now = Date.now();
        const elapsed = now - sessionTime;

        if (elapsed < SESSION_DURATION_MS) {
          // Session is still valid, refresh the timestamp
          localStorage.setItem(PIN_SESSION_TIMESTAMP, now.toString());
          setIsVerified(true);
        } else {
          // Session expired, clear it
          clearSession();
          setIsVerified(false);
        }
      } else {
        setIsVerified(false);
      }
      setIsLoading(false);
    };

    checkSession();
  }, []);

  const setVerified = () => {
    const now = Date.now();
    localStorage.setItem(PIN_SESSION_KEY, "true");
    localStorage.setItem(PIN_SESSION_TIMESTAMP, now.toString());
    setIsVerified(true);
  };

  const clearSession = () => {
    localStorage.removeItem(PIN_SESSION_KEY);
    localStorage.removeItem(PIN_SESSION_TIMESTAMP);
    setIsVerified(false);
  };

  const getSessionTimeRemaining = (): number => {
    const timestamp = localStorage.getItem(PIN_SESSION_TIMESTAMP);
    if (!timestamp) return 0;

    const sessionTime = parseInt(timestamp, 10);
    const now = Date.now();
    const elapsed = now - sessionTime;
    const remaining = Math.max(0, SESSION_DURATION_MS - elapsed);

    return remaining;
  };

  return {
    isVerified,
    isLoading,
    setVerified,
    clearSession,
    getSessionTimeRemaining,
    SESSION_DURATION_MS,
  };
}
