import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, Zap, TrendingUp, AlertTriangle, Download } from "lucide-react";
import { useState } from "react";
import BackToTerminalButton from "@/components/BackToTerminalButton";

export default function TenantDashboard() {
  const { user } = useAuth();
  const [selectedLeadId, setSelectedLeadId] = useState<number | null>(null);

  // Fetch tenant info
  const { data: tenant } = trpc.tenantAdmin.getTenant.useQuery();

  // Fetch tenant statistics
  const { data: stats } = trpc.tenantAdmin.getStats.useQuery();

  // Fetch leads
  const { data: leads, isLoading: leadsLoading } = trpc.leads.list.useQuery({ limit: 50 });

  if (user?.role === "master_admin") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Card className="p-8 text-center border-border bg-card">
          <AlertCircle className="mx-auto mb-4 h-12 w-12 text-destructive" />
          <h2 className="text-2xl font-bold text-foreground">Wrong Dashboard</h2>
          <p className="mt-2 text-muted-foreground">Use the Master Admin Dashboard instead.</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <BackToTerminalButton className="mb-4" />
          <h1 className="text-4xl font-bold text-foreground">{tenant?.name || "Tenant Dashboard"}</h1>
          <p className="mt-2 text-muted-foreground">Lead management and performance overview</p>
        </div>

        {/* Statistics Grid */}
        <div className="mb-8 grid grid-cols-1 gap-4 md:grid-cols-5">
          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Leads</p>
                <p className="text-3xl font-bold text-foreground">{stats?.totalLeads || 0}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-primary/50" />
            </div>
          </Card>

          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Emergency</p>
                <p className="text-3xl font-bold text-destructive">{stats?.emergencyLeads || 0}</p>
              </div>
              <Zap className="h-8 w-8 text-destructive/50" />
            </div>
          </Card>

          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Follow-up</p>
                <p className="text-3xl font-bold text-secondary">{stats?.followUpLeads || 0}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-secondary/50" />
            </div>
          </Card>

          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Spam</p>
                <p className="text-3xl font-bold text-muted-foreground">{stats?.spamLeads || 0}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-muted-foreground/50" />
            </div>
          </Card>

          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Paused</p>
                <p className="text-3xl font-bold text-accent">{stats?.pausedLeads || 0}</p>
              </div>
              <AlertCircle className="h-8 w-8 text-accent/50" />
            </div>
          </Card>
        </div>

        {/* Leads List */}
        <div>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-foreground">Recent Leads</h2>
            <Button variant="outline" size="sm" className="border-border text-foreground hover:bg-muted">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>

          {leadsLoading ? (
            <Card className="border-border bg-card p-6">
              <p className="text-center text-muted-foreground">Loading leads...</p>
            </Card>
          ) : leads && leads.length > 0 ? (
            <div className="space-y-3">
              {leads.map((lead) => (
                <Card
                  key={lead.id}
                  className="border-border bg-card p-4 hover:border-primary/50 transition-smooth cursor-pointer"
                  onClick={() => setSelectedLeadId(lead.id)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <h3 className="font-semibold text-foreground">{lead.name || "Unknown"}</h3>
                        <span
                          className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${
                            lead.category === "emergency"
                              ? "bg-destructive/20 text-destructive"
                              : lead.category === "follow_up"
                                ? "bg-secondary/20 text-secondary"
                                : "bg-muted/20 text-muted-foreground"
                          }`}
                        >
                          {lead.category || "uncategorized"}
                        </span>
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground">{lead.email || lead.phone || "No contact info"}</p>
                      <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{lead.message}</p>
                      <p className="mt-2 text-xs text-muted-foreground">
                        {new Date(lead.createdAt).toLocaleString()}
                      </p>
                    </div>
                    <div className="ml-4 text-right">
                      {lead.categoryConfidence && (
                        <p className="text-sm font-medium text-primary">
                          {String(((typeof lead.categoryConfidence === "string"
                            ? parseFloat(lead.categoryConfidence)
                            : lead.categoryConfidence) || 0) * 100).split(".")[0]}% confidence
                        </p>
                      )}
                      {lead.selfCorrectionTriggered && (
                        <p className="mt-1 text-xs text-accent">Self-corrected</p>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="border-border bg-card p-6">
              <p className="text-center text-muted-foreground">No leads yet. Incoming leads will appear here.</p>
            </Card>
          )}
        </div>

        {/* Lead Detail View */}
        {selectedLeadId && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
            <Card className="border-border bg-card w-full max-w-2xl max-h-96 overflow-y-auto p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold text-foreground">Lead Details</h2>
                <button
                  onClick={() => setSelectedLeadId(null)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  ✕
                </button>
              </div>
              {leads?.find((l) => l.id === selectedLeadId) && (
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Name</p>
                    <p className="text-foreground">{leads.find((l) => l.id === selectedLeadId)?.name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Email</p>
                    <p className="text-foreground">{leads.find((l) => l.id === selectedLeadId)?.email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Phone</p>
                    <p className="text-foreground">{leads.find((l) => l.id === selectedLeadId)?.phone}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Message</p>
                    <p className="text-foreground">{leads.find((l) => l.id === selectedLeadId)?.message}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Categorization Reason</p>
                    <p className="text-foreground">{leads.find((l) => l.id === selectedLeadId)?.categoryReason}</p>
                  </div>
                </div>
              )}
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
