import { invokeLLM } from "./_core/llm";
import { notifyOwner } from "./_core/notification";
import type { Message } from "./_core/llm";

/**
 * LLM Auditor System
 * Real-time validation of AI bot outputs with confidence scoring
 * Detects hallucinations, logic errors, and inconsistencies
 */

export interface AuditResult {
  botName: string;
  confidence: number; // 0-100
  isValid: boolean;
  errors: string[];
  suggestions: string[];
  timestamp: Date;
  requiresHumanReview: boolean;
}

export interface BotOutput {
  botName: "triage" | "billing" | "communication";
  action: string;
  reasoning: string;
  output: string;
  metadata?: Record<string, unknown>;
}

/**
 * Audit a bot's output using LLM validation
 * Returns confidence score and any detected issues
 */
export async function auditBotOutput(botOutput: BotOutput): Promise<AuditResult> {
  try {
    const auditPrompt = `You are a security auditor for an HVAC lead management system. 
    
Analyze the following bot output for:
1. Logical consistency and correctness
2. Hallucinations or made-up information
3. Appropriate confidence levels
4. Compliance with business rules
5. Potential security or privacy issues

Bot Information:
- Name: ${botOutput.botName}
- Action: ${botOutput.action}
- Reasoning: ${botOutput.reasoning}
- Output: ${botOutput.output}

Respond with a JSON object containing:
{
  "confidence": <0-100 score>,
  "isValid": <boolean>,
  "errors": [<list of detected issues>],
  "suggestions": [<list of improvements>],
  "requiresHumanReview": <boolean if confidence < 85 or errors found>
}`;    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "You are a security auditor. Respond ONLY with valid JSON, no other text.",
        },
        {
          role: "user",
          content: auditPrompt,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "audit_result",
          strict: true,
          schema: {
            type: "object",
            properties: {
              confidence: {
                type: "number",
                description: "Confidence score 0-100",
              },
              isValid: {
                type: "boolean",
                description: "Whether the output is valid",
              },
              errors: {
                type: "array",
                items: { type: "string" },
                description: "List of detected errors",
              },
              suggestions: {
                type: "array",
                items: { type: "string" },
                description: "List of suggestions",
              },
              requiresHumanReview: {
                type: "boolean",
                description: "Whether human review is needed",
              },
            },
            required: [
              "confidence",
              "isValid",
              "errors",
              "suggestions",
              "requiresHumanReview",
            ],
            additionalProperties: false,
          },
        },
      },
    });

    // Parse the LLM response
    const content = response.choices[0].message.content;
    const auditData = typeof content === "string" ? JSON.parse(content) : content;

    const result: AuditResult = {
      botName: botOutput.botName,
      confidence: auditData.confidence,
      isValid: auditData.isValid,
      errors: auditData.errors || [],
      suggestions: auditData.suggestions || [],
      timestamp: new Date(),
      requiresHumanReview: auditData.requiresHumanReview,
    };

    // Alert owner if confidence is low or errors detected
    if (result.confidence < 85 || result.errors.length > 0) {
      await notifyOwner({
        title: `Auditor Alert: ${result.botName} Bot`,
        content: `Confidence: ${result.confidence}%\nErrors: ${result.errors.join(", ") || "None"}\nAction: Review and consider manual intervention.`,
      });
    }

    return result;
  } catch (error) {
    console.error("Auditor error:", error);
    // Return a conservative result on error
    return {
      botName: botOutput.botName,
      confidence: 0,
      isValid: false,
      errors: ["Auditor validation failed"],
      suggestions: ["Manual review required"],
      timestamp: new Date(),
      requiresHumanReview: true,
    };
  }
}

/**
 * Audit multiple bot outputs and return consolidated result
 */
export async function auditBotHierarchy(
  outputs: BotOutput[]
): Promise<AuditResult[]> {
  const results = await Promise.all(outputs.map((output) => auditBotOutput(output)));
  return results;
}

/**
 * Trigger auto-fix for a bot that failed audit
 * Uses LLM to suggest and implement corrections
 */
export async function triggerAutoFix(
  botOutput: BotOutput,
  auditResult: AuditResult
): Promise<BotOutput | null> {
  try {
    const fixPrompt = `The following bot output failed audit validation:

Bot: ${botOutput.botName}
Output: ${botOutput.output}
Errors: ${auditResult.errors.join(", ")}
Suggestions: ${auditResult.suggestions.join(", ")}

Generate a corrected version of the bot output that addresses all errors and suggestions.
Respond with a JSON object containing:
{
  "correctedOutput": <corrected output string>,
  "explanation": <explanation of changes>,
  "confidence": <new confidence score 0-100>
}`;
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "You are a bot output corrector. Respond ONLY with valid JSON, no other text.",
        },
        {
          role: "user",
          content: fixPrompt,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "fix_result",
          strict: true,
          schema: {
            type: "object",
            properties: {
              correctedOutput: {
                type: "string",
                description: "Corrected output",
              },
              explanation: {
                type: "string",
                description: "Explanation of changes",
              },
              confidence: {
                type: "number",
                description: "New confidence score",
              },
            },
            required: ["correctedOutput", "explanation", "confidence"],
            additionalProperties: false,
          },
        },
      },
    });

    const content = response.choices[0].message.content;
    const fixData = typeof content === "string" ? JSON.parse(content) : content;

    return {
      ...botOutput,
      output: fixData.correctedOutput,
      reasoning: `${botOutput.reasoning}\n\nAuto-fix applied: ${fixData.explanation}`,
    };
  } catch (error) {
    console.error("Auto-fix error:", error);
    return null;
  }
}
