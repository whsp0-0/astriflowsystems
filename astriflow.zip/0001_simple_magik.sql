CREATE TABLE `agentExecutionLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tenantId` int NOT NULL,
	`leadId` int NOT NULL,
	`agentType` enum('lead_worker','safety_critic','master_auditor') NOT NULL,
	`agentVersion` varchar(50) DEFAULT '1.0',
	`action` varchar(255) NOT NULL,
	`input` json,
	`output` json,
	`status` enum('success','failure','error') NOT NULL,
	`errorMessage` text,
	`consecutiveFailureCount` int DEFAULT 0,
	`executedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `agentExecutionLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `leads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tenantId` int NOT NULL,
	`sourceChannel` varchar(50) DEFAULT 'instagram_dm',
	`sourceId` varchar(255),
	`name` varchar(255),
	`email` varchar(320),
	`phone` varchar(20),
	`message` text,
	`category` enum('emergency','follow_up','spam','uncategorized') DEFAULT 'uncategorized',
	`categoryConfidence` decimal(3,2),
	`categoryReason` text,
	`categoryAuditedAt` timestamp,
	`categoryAuditedBy` int,
	`selfCorrectionTriggered` boolean DEFAULT false,
	`selfCorrectionReason` text,
	`selfCorrectionAttempts` int DEFAULT 0,
	`status` enum('pending','processing','categorized','paused','archived') DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `leads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `pausedLeads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tenantId` int NOT NULL,
	`leadId` int NOT NULL,
	`pauseReason` text NOT NULL,
	`failingAgentType` varchar(50) NOT NULL,
	`consecutiveFailureCount` int NOT NULL,
	`resolvedAt` timestamp,
	`resolvedBy` int,
	`resolutionNotes` text,
	`pausedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `pausedLeads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `systemAlerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tenantId` int,
	`alertType` enum('agent_failure','subscription_issue','lead_pause','system_error') NOT NULL,
	`title` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`leadId` int,
	`relatedData` json,
	`severity` enum('info','warning','critical') DEFAULT 'warning',
	`isRead` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `systemAlerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tenants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320),
	`phone` varchar(20),
	`stripeCustomerId` varchar(255),
	`stripeSubscriptionId` varchar(255),
	`subscriptionStatus` enum('active','trialing','past_due','canceled','unpaid') DEFAULT 'trialing',
	`businessType` varchar(100) DEFAULT 'HVAC',
	`address` text,
	`city` varchar(100),
	`state` varchar(50),
	`zipCode` varchar(20),
	`agentEnabled` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tenants_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transcriptLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tenantId` int NOT NULL,
	`leadId` int NOT NULL,
	`transcript` text NOT NULL,
	`categoryAtSnapshot` varchar(50),
	`categoryReasonAtSnapshot` text,
	`selfCorrectionApplied` boolean DEFAULT false,
	`selfCorrectionDetails` json,
	`visibleToMasterAdmin` boolean DEFAULT true,
	`visibleToTenantAdmin` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `transcriptLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('master_admin','tenant_admin','tenant_user') NOT NULL DEFAULT 'tenant_user';--> statement-breakpoint
ALTER TABLE `users` ADD `tenantId` int;--> statement-breakpoint
ALTER TABLE `agentExecutionLogs` ADD CONSTRAINT `agentExecutionLogs_tenantId_tenants_id_fk` FOREIGN KEY (`tenantId`) REFERENCES `tenants`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `agentExecutionLogs` ADD CONSTRAINT `agentExecutionLogs_leadId_leads_id_fk` FOREIGN KEY (`leadId`) REFERENCES `leads`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `leads` ADD CONSTRAINT `leads_tenantId_tenants_id_fk` FOREIGN KEY (`tenantId`) REFERENCES `tenants`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `pausedLeads` ADD CONSTRAINT `pausedLeads_tenantId_tenants_id_fk` FOREIGN KEY (`tenantId`) REFERENCES `tenants`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `pausedLeads` ADD CONSTRAINT `pausedLeads_leadId_leads_id_fk` FOREIGN KEY (`leadId`) REFERENCES `leads`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `transcriptLogs` ADD CONSTRAINT `transcriptLogs_tenantId_tenants_id_fk` FOREIGN KEY (`tenantId`) REFERENCES `tenants`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `transcriptLogs` ADD CONSTRAINT `transcriptLogs_leadId_leads_id_fk` FOREIGN KEY (`leadId`) REFERENCES `leads`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `idx_agentExecutionLogs_tenantId` ON `agentExecutionLogs` (`tenantId`);--> statement-breakpoint
CREATE INDEX `idx_agentExecutionLogs_leadId` ON `agentExecutionLogs` (`leadId`);--> statement-breakpoint
CREATE INDEX `idx_agentExecutionLogs_agentType` ON `agentExecutionLogs` (`agentType`);--> statement-breakpoint
CREATE INDEX `idx_agentExecutionLogs_status` ON `agentExecutionLogs` (`status`);--> statement-breakpoint
CREATE INDEX `idx_leads_tenantId` ON `leads` (`tenantId`);--> statement-breakpoint
CREATE INDEX `idx_leads_category` ON `leads` (`category`);--> statement-breakpoint
CREATE INDEX `idx_leads_status` ON `leads` (`status`);--> statement-breakpoint
CREATE INDEX `idx_leads_createdAt` ON `leads` (`createdAt`);--> statement-breakpoint
CREATE INDEX `idx_pausedLeads_tenantId` ON `pausedLeads` (`tenantId`);--> statement-breakpoint
CREATE INDEX `idx_pausedLeads_leadId` ON `pausedLeads` (`leadId`);--> statement-breakpoint
CREATE INDEX `idx_pausedLeads_pausedAt` ON `pausedLeads` (`pausedAt`);--> statement-breakpoint
CREATE INDEX `idx_systemAlerts_tenantId` ON `systemAlerts` (`tenantId`);--> statement-breakpoint
CREATE INDEX `idx_systemAlerts_alertType` ON `systemAlerts` (`alertType`);--> statement-breakpoint
CREATE INDEX `idx_systemAlerts_isRead` ON `systemAlerts` (`isRead`);--> statement-breakpoint
CREATE INDEX `idx_systemAlerts_createdAt` ON `systemAlerts` (`createdAt`);--> statement-breakpoint
CREATE INDEX `idx_tenants_stripeCustomerId` ON `tenants` (`stripeCustomerId`);--> statement-breakpoint
CREATE INDEX `idx_tenants_subscriptionStatus` ON `tenants` (`subscriptionStatus`);--> statement-breakpoint
CREATE INDEX `idx_transcriptLogs_tenantId` ON `transcriptLogs` (`tenantId`);--> statement-breakpoint
CREATE INDEX `idx_transcriptLogs_leadId` ON `transcriptLogs` (`leadId`);--> statement-breakpoint
CREATE INDEX `idx_users_tenantId` ON `users` (`tenantId`);--> statement-breakpoint
CREATE INDEX `idx_users_role` ON `users` (`role`);