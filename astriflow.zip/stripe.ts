import Stripe from "stripe";
import { getDb } from "./db";
import { tenants } from "../drizzle/schema";
import { eq } from "drizzle-orm";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");

/**
 * STRIPE INTEGRATION FOR ASTRIFLOW
 * Handles subscription link generation and customer management
 */

export interface SubscriptionLinkResult {
  checkoutUrl: string;
  sessionId: string;
}

/**
 * Generate a Stripe checkout session for tenant subscription
 * This creates a one-time link that the Master Admin can share with the HVAC company
 */
export async function generateSubscriptionLink(
  tenantId: number,
  origin: string
): Promise<SubscriptionLinkResult> {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // Get tenant details
    const tenantResult = await db.select().from(tenants).where(eq(tenants.id, tenantId)).limit(1);
    if (tenantResult.length === 0) throw new Error("Tenant not found");

    const tenant = tenantResult[0];

    // Create or get Stripe customer
    let stripeCustomerId = tenant.stripeCustomerId;

    if (!stripeCustomerId) {
      const customer = await stripe.customers.create({
        name: tenant.name,
        email: tenant.email || undefined,
        phone: tenant.phone || undefined,
        metadata: {
          tenantId: tenantId.toString(),
          businessType: tenant.businessType,
        },
      });

      stripeCustomerId = customer.id;

      // Update tenant with Stripe customer ID
      await db.update(tenants).set({ stripeCustomerId }).where(eq(tenants.id, tenantId));
    }

    // Create checkout session for subscription
    const session = await stripe.checkout.sessions.create({
      customer: stripeCustomerId,
      mode: "subscription",
      line_items: [
        {
          price: process.env.STRIPE_PRICE_ID || "price_1234567890", // You'll need to set this
          quantity: 1,
        },
      ],
      success_url: `${origin}/tenant`,
      cancel_url: `${origin}/master-admin`,
      metadata: {
        tenantId: tenantId.toString(),
      },
    });

    if (!session.url) throw new Error("Failed to generate checkout URL");

    return {
      checkoutUrl: session.url,
      sessionId: session.id,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to generate subscription link: ${errorMessage}`);
  }
}

/**
 * Handle Stripe webhook for subscription events
 */
export async function handleStripeWebhook(event: any): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database connection failed");

  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object as Stripe.Checkout.Session;
      const tenantId = parseInt(session.metadata?.tenantId || "0");

      if (tenantId > 0 && session.subscription) {
        const subscriptionId = typeof session.subscription === "string" ? session.subscription : session.subscription.id;

        // Update tenant with subscription details
        await db.update(tenants).set({
          stripeSubscriptionId: subscriptionId,
          subscriptionStatus: "active",
        }).where(eq(tenants.id, tenantId));

        console.log(`[Stripe] Subscription activated for tenant ${tenantId}`);
      }
      break;
    }

    case "customer.subscription.updated": {
      const subscription = event.data.object as Stripe.Subscription;
      const tenantId = parseInt(subscription.metadata?.tenantId || "0");

      if (tenantId > 0) {
        const status = subscription.status as "active" | "trialing" | "past_due" | "canceled" | "unpaid";

        await db.update(tenants).set({
          subscriptionStatus: status,
        }).where(eq(tenants.id, tenantId));

        console.log(`[Stripe] Subscription updated for tenant ${tenantId}: ${status}`);
      }
      break;
    }

    case "customer.subscription.deleted": {
      const subscription = event.data.object as Stripe.Subscription;
      const tenantId = parseInt(subscription.metadata?.tenantId || "0");

      if (tenantId > 0) {
        await db.update(tenants).set({
          subscriptionStatus: "canceled",
        }).where(eq(tenants.id, tenantId));

        console.log(`[Stripe] Subscription canceled for tenant ${tenantId}`);
      }
      break;
    }

    case "invoice.payment_succeeded": {
      const invoice = event.data.object as Stripe.Invoice;
      console.log(`[Stripe] Payment succeeded for customer ${invoice.customer}`);
      break;
    }

    case "invoice.payment_failed": {
      const invoice = event.data.object as Stripe.Invoice;
      console.log(`[Stripe] Payment failed for customer ${invoice.customer}`);
      break;
    }

    default:
      console.log(`[Stripe] Unhandled event type: ${event.type}`);
  }
}

/**
 * Get subscription details for a tenant
 */
export async function getSubscriptionDetails(tenantId: number) {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    const tenantResult = await db.select().from(tenants).where(eq(tenants.id, tenantId)).limit(1);
    if (tenantResult.length === 0) throw new Error("Tenant not found");

    const tenant = tenantResult[0];

    if (!tenant.stripeSubscriptionId) {
      return null;
    }

    const subscription = await stripe.subscriptions.retrieve(tenant.stripeSubscriptionId);
    return subscription;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to get subscription details: ${errorMessage}`);
  }
}

/**
 * Cancel a subscription
 */
export async function cancelSubscription(tenantId: number): Promise<void> {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    const tenantResult = await db.select().from(tenants).where(eq(tenants.id, tenantId)).limit(1);
    if (tenantResult.length === 0) throw new Error("Tenant not found");

    const tenant = tenantResult[0];

    if (!tenant.stripeSubscriptionId) {
      throw new Error("No subscription found for this tenant");
    }

    await stripe.subscriptions.cancel(tenant.stripeSubscriptionId);

    // Update tenant status
    await db.update(tenants).set({
      subscriptionStatus: "canceled",
    }).where(eq(tenants.id, tenantId));

    console.log(`[Stripe] Subscription canceled for tenant ${tenantId}`);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to cancel subscription: ${errorMessage}`);
  }
}
