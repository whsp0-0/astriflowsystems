import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { AlertCircle, CheckCircle, LogOut, RefreshCw } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";

/**
 * EmployeeWatcherDashboard: View for staff/watchers
 * Shows only flagged leads that couldn't be categorized
 * Limited to [Approve] and [Re-Categorize] actions
 */
export default function EmployeeWatcherDashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [selectedLeadId, setSelectedLeadId] = useState<number | null>(null);

  // Fetch flagged leads (paused leads that need manual review)
  const { data: flaggedLeads = [], isLoading } = trpc.leads.list.useQuery();

  const approveMutation = trpc.leads.resolvePaused.useMutation({
    onSuccess: () => {
      setSelectedLeadId(null);
    },
  });

  const recategorizeMutation = trpc.leads.resolvePaused.useMutation({
    onSuccess: () => {
      setSelectedLeadId(null);
    },
  });

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  const handleApprove = (leadId: number) => {
    approveMutation.mutate({ leadId, resolutionNotes: "Approved by staff" });
  };

  const handleRecategorize = (leadId: number) => {
    recategorizeMutation.mutate({ leadId, resolutionNotes: "Requested re-categorization" });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-foreground">
                Flagged Leads Review
              </h1>
              <p className="text-xs text-muted-foreground mt-1">
                {user?.name} • Staff
              </p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-muted-foreground hover:text-foreground"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-4xl mx-auto">
          {/* Info Card */}
          <Card className="bg-card border border-border mb-6">
            <div className="p-6">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                <div>
                  <h2 className="font-semibold text-foreground">Your Role</h2>
                  <p className="text-sm text-muted-foreground mt-1">
                    Review leads that the AI couldn't categorize. Use the buttons below to approve the categorization or trigger re-categorization.
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Flagged Leads List */}
          {isLoading ? (
            <Card className="bg-card border border-border">
              <div className="p-6 text-center text-muted-foreground">
                Loading flagged leads...
              </div>
            </Card>
          ) : flaggedLeads.length === 0 ? (
            <Card className="bg-card border border-border">
              <div className="p-6 text-center">
                <CheckCircle className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-foreground font-medium">No Flagged Leads</p>
                <p className="text-sm text-muted-foreground mt-1">
                  All leads have been successfully categorized.
                </p>
              </div>
            </Card>
          ) : (
            <div className="space-y-4">
              {flaggedLeads.map((lead: any) => (
                <Card
                  key={lead.id}
                  className={`bg-card border ${
                    selectedLeadId === lead.id ? "border-primary" : "border-border"
                  }`}
                >
                  <div className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Name</p>
                        <p className="font-medium text-foreground mt-1">{lead.name}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Email</p>
                        <p className="font-medium text-foreground mt-1">{lead.email}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Phone</p>
                        <p className="font-medium text-foreground mt-1">{lead.phone || "—"}</p>
                      </div>
                    </div>

                    <div className="mb-4 p-4 bg-background rounded-sm border border-border">
                      <p className="text-sm text-muted-foreground">Message</p>
                      <p className="text-foreground mt-2">{lead.message}</p>
                    </div>

                    <div className="mb-4">
                      <p className="text-sm text-muted-foreground mb-2">Last Categorization Attempt</p>
                      <div className="p-3 bg-background rounded-sm border border-border">
                        <p className="text-sm text-foreground">
                          <span className="font-medium">Category:</span> {lead.category || "Uncategorized"}
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">
                          <span className="font-medium">Reason:</span> {lead.failureReason || "Unknown"}
                        </p>
                      </div>
                    </div>

            <div className="flex gap-3">
              <Button
                onClick={() => handleApprove(lead.id)}
                disabled={approveMutation.isPending || recategorizeMutation.isPending}
                className="flex-1 bg-background border border-border text-foreground hover:bg-card font-medium text-sm"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Approve
              </Button>
              <Button
                onClick={() => handleRecategorize(lead.id)}
                disabled={approveMutation.isPending || recategorizeMutation.isPending}
                className="flex-1 bg-background border border-border text-foreground hover:bg-card font-medium text-sm"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Re-Categorize
              </Button>
            </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
