import { describe, expect, it, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createContextWithUser(email: string, role: string): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "sample-user",
    email,
    name: "Test User",
    loginMethod: "manus",
    role: role as any,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("Owner Routing - PRIMARY_OWNER_EMAIL", () => {
  beforeEach(() => {
    // Verify the environment variable is set
    expect(process.env.PRIMARY_OWNER_EMAIL).toBe("astriflowsystems@gmail.com");
  });

  it("should have PRIMARY_OWNER_EMAIL environment variable configured", () => {
    const ownerEmail = process.env.PRIMARY_OWNER_EMAIL;
    expect(ownerEmail).toBeDefined();
    expect(ownerEmail).toBe("astriflowsystems@gmail.com");
    expect(ownerEmail).toMatch(/^[^\s@]+@[^\s@]+\.[^\s@]+$/); // Valid email format
  });

  it("should identify owner by email match", () => {
    const ownerEmail = process.env.PRIMARY_OWNER_EMAIL;
    const testEmail = "astriflowsystems@gmail.com";
    
    expect(testEmail).toBe(ownerEmail);
  });

  it("should distinguish owner from staff users", () => {
    const ownerEmail = process.env.PRIMARY_OWNER_EMAIL;
    const staffEmails = [
      "staff@company.com",
      "employee@company.com",
      "admin@company.com",
    ];

    staffEmails.forEach((email) => {
      expect(email).not.toBe(ownerEmail);
    });
  });

  it("should verify auth context with owner email", () => {
    const ownerEmail = process.env.PRIMARY_OWNER_EMAIL!;
    const ctx = createContextWithUser(ownerEmail, "master_admin");

    expect(ctx.user?.email).toBe(ownerEmail);
    expect(ctx.user?.role).toBe("master_admin");
  });

  it("should verify auth context with staff email", () => {
    const ctx = createContextWithUser("staff@example.com", "tenant_user");

    expect(ctx.user?.email).toBe("staff@example.com");
    expect(ctx.user?.role).toBe("tenant_user");
    expect(ctx.user?.email).not.toBe(process.env.PRIMARY_OWNER_EMAIL);
  });

  it("should validate email format of PRIMARY_OWNER_EMAIL", () => {
    const ownerEmail = process.env.PRIMARY_OWNER_EMAIL!;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    expect(emailRegex.test(ownerEmail)).toBe(true);
    expect(ownerEmail).toContain("@");
    expect(ownerEmail).toContain(".");
  });
});
