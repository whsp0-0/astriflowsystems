import { useEffect, useState } from "react";

export interface Lead {
  id: number;
  name: string;
  email: string;
  phone: string;
  message: string;
  category: "emergency" | "follow_up" | "spam";
  confidence: number;
  status: string;
  created_at: string;
  priority: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  assigned_to: string;
}

export interface Employee {
  id: number;
  name: string;
  email: string;
  phone: string;
  role: string;
  status: "active" | "on_leave";
  assigned_leads: number;
  completed_jobs: number;
  rating: number;
}

export interface Job {
  id: number;
  lead_id: number;
  customer_name: string;
  service_type: string;
  status: "scheduled" | "in_progress" | "pending" | "completed";
  scheduled_date: string;
  assigned_technician: string;
  estimated_duration_hours: number;
  estimated_cost: number;
  priority: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  notes: string;
}

export interface TenantData {
  metadata: {
    generated_at: string;
    tenant_id: number;
    tenant_name: string;
    data_version: string;
  };
  leads: Lead[];
  employees: Employee[];
  jobs: Job[];
  summary: {
    total_leads: number;
    emergency_leads: number;
    follow_up_leads: number;
    total_employees: number;
    active_employees: number;
    on_leave_employees: number;
    total_jobs: number;
    scheduled_jobs: number;
    in_progress_jobs: number;
    pending_jobs: number;
    total_revenue_potential: number;
    average_job_duration_hours: number;
  };
}

/**
 * Hook to load and manage tenant data from tenant_data.json
 */
export function useTenantData() {
  const [data, setData] = useState<TenantData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadTenantData = async () => {
      try {
        console.log("[useTenantData] Loading tenant data...");
        const response = await fetch("/tenant_data.json");

        if (!response.ok) {
          throw new Error(`Failed to load tenant data: ${response.status}`);
        }

        const tenantData: TenantData = await response.json();
        console.log("[useTenantData] Data loaded successfully:", tenantData);
        setData(tenantData);
        setError(null);
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : String(err);
        console.error("[useTenantData] Error loading data:", errorMessage);
        setError(errorMessage);
        setData(null);
      } finally {
        setLoading(false);
      }
    };

    loadTenantData();
  }, []);

  return { data, loading, error };
}

/**
 * Hook to get filtered leads by category
 */
export function useLeadsByCategory(data: TenantData | null, category?: string) {
  if (!data) return [];
  if (!category) return data.leads;
  return data.leads.filter((lead) => lead.category === category);
}

/**
 * Hook to get active employees
 */
export function useActiveEmployees(data: TenantData | null) {
  if (!data) return [];
  return data.employees.filter((emp) => emp.status === "active");
}

/**
 * Hook to get jobs by status
 */
export function useJobsByStatus(data: TenantData | null, status?: string) {
  if (!data) return [];
  if (!status) return data.jobs;
  return data.jobs.filter((job) => job.status === status);
}
