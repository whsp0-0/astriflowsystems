import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, Building2, TrendingUp, AlertTriangle, Users, Activity, Zap, Wrench } from "lucide-react";
import { useState } from "react";
import CreateTenantDialog from "@/components/CreateTenantDialog";
import { useDeveloperTest } from "@/hooks/useDeveloperTest";
import TenantManagementPanel from "@/components/TenantManagementPanel";
import PINPadLogin from "@/components/PINPadLogin";

export default function MasterAdminDashboard() {
  const { user } = useAuth();
  const [showCreateTenant, setShowCreateTenant] = useState(false);
  const [selectedTenant, setSelectedTenant] = useState<number | null>(null);
  const { simulateLead, isLoading: testLoading } = useDeveloperTest();
  const [repairLoading, setRepairLoading] = useState(false);
  const [pinVerified, setPinVerified] = useState(false);

  // Fetch all tenants
  const { data: tenants, isLoading: tenantsLoading, refetch: refetchTenants } = trpc.tenants.list.useQuery();

  // Fetch system alerts
  const { data: alerts } = trpc.alerts.list.useQuery({ limit: 10 });

  // REPAIR SYSTEM mutation
  const runRepair = trpc.repairSystem.run.useMutation({
    onSuccess: (result: any) => {
      setRepairLoading(false);
      alert(`REPAIR SYSTEM Complete\n\nIssues Found: ${result.issuesFound.length}\nIssues Fixed: ${result.issuesFixed.length}\n\nCheck alerts for details.`);
      refetchTenants();
    },
    onError: (err: any) => {
      setRepairLoading(false);
      alert(`REPAIR SYSTEM Error: ${err.message}`);
    },
  });

  // Calculate statistics
  const activeSubscriptions = tenants?.filter((t) => t.subscriptionStatus === "active").length || 0;
  const trialingTenants = tenants?.filter((t) => t.subscriptionStatus === "trialing").length || 0;
  const totalTenants = tenants?.length || 0;
  const criticalAlerts = alerts?.filter((a) => a.severity === "critical").length || 0;

  // PIN-pad security
  if (!pinVerified) {
    return <PINPadLogin onSuccess={() => setPinVerified(true)} correctPIN="2987" />;
  }

  if (user?.role !== "master_admin") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Card className="p-8 text-center">
          <AlertCircle className="mx-auto mb-4 h-12 w-12 text-destructive" />
          <h2 className="text-2xl font-bold text-foreground">Access Denied</h2>
          <p className="mt-2 text-muted-foreground">You do not have permission to access this page.</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground">Master Admin Dashboard</h1>
            <p className="mt-2 text-muted-foreground">System-wide oversight and tenant management</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => setShowCreateTenant(true)} className="bg-primary hover:bg-primary/90">
              <Building2 className="mr-2 h-4 w-4" />
              Add Tenant
            </Button>
            <Button
              onClick={() => simulateLead()}
              disabled={testLoading}
              variant="outline"
              size="sm"
              title="Ctrl+Shift+T"
              className="text-xs opacity-50 hover:opacity-100"
            >
              <Zap className="mr-1 h-3 w-3" />
              Dev Test
            </Button>
            <Button
              onClick={() => {
                setRepairLoading(true);
                runRepair.mutate();
              }}
              disabled={repairLoading}
              variant="outline"
              size="sm"
              title="Run system diagnostics and auto-repair"
              className="text-xs opacity-50 hover:opacity-100"
            >
              <Wrench className="mr-1 h-3 w-3" />
              REPAIR
            </Button>
          </div>
        </div>

        {/* Statistics Grid */}
        <div className="mb-8 grid grid-cols-1 gap-4 md:grid-cols-4">
          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Tenants</p>
                <p className="text-3xl font-bold text-primary">{totalTenants}</p>
              </div>
              <Building2 className="h-8 w-8 text-primary/50" />
            </div>
          </Card>

          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Subscriptions</p>
                <p className="text-3xl font-bold text-secondary">{activeSubscriptions}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-secondary/50" />
            </div>
          </Card>

          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Trial Tenants</p>
                <p className="text-3xl font-bold text-accent">{trialingTenants}</p>
              </div>
              <Activity className="h-8 w-8 text-accent/50" />
            </div>
          </Card>

          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Critical Alerts</p>
                <p className={`text-3xl font-bold ${criticalAlerts > 0 ? "text-destructive" : "text-muted-foreground"}`}>
                  {criticalAlerts}
                </p>
              </div>
              <AlertTriangle className="h-8 w-8 text-destructive/50" />
            </div>
          </Card>
        </div>

        {/* Critical Alerts Section */}
        {criticalAlerts > 0 && (
          <div className="mb-8">
            <h2 className="mb-4 text-2xl font-bold text-foreground">Critical Alerts</h2>
            <Card className="border-destructive/30 bg-destructive/5 p-6">
              {alerts
                ?.filter((a) => a.severity === "critical")
                .map((alert) => (
                  <div key={alert.id} className="mb-4 flex items-start gap-4 border-b border-border pb-4 last:border-b-0">
                    <AlertTriangle className="h-5 w-5 flex-shrink-0 text-destructive" />
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground">{alert.title}</h3>
                      <p className="mt-1 text-sm text-muted-foreground">{alert.message}</p>
                      <p className="mt-2 text-xs text-muted-foreground">
                        {new Date(alert.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
            </Card>
          </div>
        )}

        {/* Tenants List & Management */}
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <h2 className="mb-4 text-2xl font-bold text-foreground">Tenants</h2>
            {tenantsLoading ? (
              <Card className="border-border bg-card p-6">
                <p className="text-center text-muted-foreground">Loading tenants...</p>
              </Card>
            ) : tenants && tenants.length > 0 ? (
              <div className="space-y-4">
                {tenants.map((tenant) => (
                  <Card
                    key={tenant.id}
                    onClick={() => setSelectedTenant(tenant.id)}
                    className={`border-border bg-card p-6 cursor-pointer transition-all hover:border-primary/50 ${
                      selectedTenant === tenant.id ? "border-primary ring-1 ring-primary" : ""
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-foreground">{tenant.name}</h3>
                        <p className="mt-1 text-sm text-muted-foreground">{tenant.email || "No email"}</p>
                        <div className="mt-3 flex gap-2">
                          <span
                            className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-medium ${
                              tenant.subscriptionStatus === "active"
                                ? "bg-green-500/20 text-green-400"
                                : tenant.subscriptionStatus === "trialing"
                                  ? "bg-blue-500/20 text-blue-400"
                                  : "bg-yellow-500/20 text-yellow-400"
                            }`}
                          >
                            {tenant.subscriptionStatus}
                          </span>
                          {tenant.agentEnabled && (
                            <span className="inline-flex items-center rounded-full bg-primary/20 px-3 py-1 text-xs font-medium text-primary">
                              Agents Enabled
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="border-border bg-card p-6">
                <p className="text-center text-muted-foreground">No tenants yet. Create one to get started.</p>
              </Card>
            )}
          </div>

          {/* Master Button Controls */}
          {selectedTenant && tenants && (
            <div>
              <h2 className="mb-4 text-2xl font-bold text-foreground">Master Controls</h2>
              <TenantManagementPanel
                tenant={tenants.find((t) => t.id === selectedTenant)!}
                onRefresh={refetchTenants}
              />
            </div>
          )}
        </div>
      </div>

      {/* Create Tenant Dialog */}
      <CreateTenantDialog open={showCreateTenant} onOpenChange={setShowCreateTenant} onSuccess={refetchTenants} />
    </div>
  );
}
