import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure, masterAdminProcedure, tenantAdminProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { tenants, users, leads, systemAlerts } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { processLeadPipeline } from "./agents";
import { generateSubscriptionLink } from "./stripe";
import { runRepairSystem, createRepairAlert } from "./repair-system";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  /**
   * TENANT MANAGEMENT ROUTERS
   * Master Admin only operations
   */
  tenants: router({
    // Get all tenants (Master Admin only)
    list: masterAdminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(tenants);
    }),

    // Get single tenant
    get: masterAdminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return null;
        const result = await db.select().from(tenants).where(eq(tenants.id, input.id)).limit(1);
        return result.length > 0 ? result[0] : null;
      }),

    // Create new tenant (One-Click Setup)
    create: masterAdminProcedure
      .input(
        z.object({
          name: z.string().min(1, "Business name required"),
          email: z.string().email().optional(),
          phone: z.string().optional(),
          address: z.string().optional(),
          city: z.string().optional(),
          state: z.string().optional(),
          zipCode: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database connection failed");

        const result = await db.insert(tenants).values({
          name: input.name,
          email: input.email,
          phone: input.phone,
          address: input.address,
          city: input.city,
          state: input.state,
          zipCode: input.zipCode,
          businessType: "HVAC",
          subscriptionStatus: "trialing",
          agentEnabled: true,
        });

        return { success: true, tenantId: (result as any).insertId || 0 };
      }),

    // Update tenant (e.g., after Stripe subscription)
    update: masterAdminProcedure
      .input(
        z.object({
          id: z.number(),
          stripeCustomerId: z.string().optional(),
          stripeSubscriptionId: z.string().optional(),
          subscriptionStatus: z.enum(["active", "trialing", "past_due", "canceled", "unpaid"]).optional(),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database connection failed");

        const updateData: Record<string, unknown> = {};
        if (input.stripeCustomerId) updateData.stripeCustomerId = input.stripeCustomerId;
        if (input.stripeSubscriptionId) updateData.stripeSubscriptionId = input.stripeSubscriptionId;
        if (input.subscriptionStatus) updateData.subscriptionStatus = input.subscriptionStatus;

        await db.update(tenants).set(updateData).where(eq(tenants.id, input.id));
        return { success: true };
      }),

    generateSubscriptionLink: masterAdminProcedure
      .input(z.object({ tenantId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const origin = ctx.req.headers.origin || "https://astriflow.manus.space";
        const result = await generateSubscriptionLink(input.tenantId, origin);
        return result;
      }),

    // Pause tenant - stops AI triage
    pause: masterAdminProcedure
      .input(z.object({ id: z.number(), reason: z.string().optional() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database connection failed");

        await db.update(tenants).set({ agentEnabled: false }).where(eq(tenants.id, input.id));

        return { success: true, message: "Tenant paused. AI triage disabled." };
      }),

    // Terminate tenant - cancels billing and access
    terminate: masterAdminProcedure
      .input(z.object({ id: z.number(), reason: z.string().optional() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database connection failed");

        await db.update(tenants).set({
          subscriptionStatus: "canceled",
          agentEnabled: false,
        }).where(eq(tenants.id, input.id));

        return { success: true, message: "Tenant terminated. Subscription canceled and access revoked." };
      }),

    // Delete tenant - soft delete with data archival
    delete: masterAdminProcedure
      .input(z.object({ id: z.number(), confirmDelete: z.boolean() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database connection failed");

        if (!input.confirmDelete) {
          throw new Error("Deletion must be confirmed");
        }

        const now = new Date();
        const permanentDeleteAt = new Date(now.getTime() + 24 * 60 * 60 * 1000);

        await db.update(tenants).set({
          status: "tombstone",
          tombstonedAt: now,
          permanentDeleteAt,
          subscriptionStatus: "canceled",
          agentEnabled: false,
        }).where(eq(tenants.id, input.id));

        return { success: true, message: "Tenant moved to tombstone. Will be permanently deleted in 24 hours." };
      }),

    restore: masterAdminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database connection failed");

        const result = await db.select().from(tenants).where(eq(tenants.id, input.id)).limit(1);
        if (result.length === 0) throw new Error("Tenant not found");
        if (result[0].status !== "tombstone") throw new Error("Tenant is not in tombstone status");

        const now = new Date();
        if (result[0].permanentDeleteAt && result[0].permanentDeleteAt < now) {
          throw new Error("24-hour restoration window has expired");
        }

        await db.update(tenants).set({
          status: "active",
          tombstonedAt: null,
          permanentDeleteAt: null,
          subscriptionStatus: "active",
          agentEnabled: true,
        }).where(eq(tenants.id, input.id));

        return { success: true, message: "Tenant restored successfully." };
      }),
  }),

  /**
   * LEAD MANAGEMENT ROUTERS
   */
  leads: router({
    // Get leads for current user's tenant
    list: protectedProcedure
      .input(z.object({ limit: z.number().default(100), offset: z.number().default(0) }).optional())
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) return [];

        const tenantId = ctx.user?.tenantId;
        if (!tenantId) return [];

        return db.select().from(leads).where(eq(leads.tenantId, tenantId)).limit(input?.limit || 100).offset(input?.offset || 0);
      }),

    // Get single lead with full details
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) return null;

        const tenantId = ctx.user?.tenantId;
        if (!tenantId) return null;

        const result = await db.select().from(leads).where(eq(leads.id, input.id)).limit(1);
        const lead = result.length > 0 ? result[0] : null;

        // Verify tenant access
        if (lead && lead.tenantId !== tenantId && ctx.user?.role !== "master_admin") {
          return null;
        }

        return lead;
      }),

    // Get leads by category
    getByCategory: protectedProcedure
      .input(z.object({ category: z.enum(["emergency", "follow_up", "spam", "uncategorized"]) }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) return [];

        const tenantId = ctx.user?.tenantId;
        if (!tenantId) return [];

        return db.select().from(leads).where(eq(leads.tenantId, tenantId) && eq(leads.category, input.category));
      }),

    // Get paused leads (Master Admin view)
    getPaused: masterAdminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];

      return db.select().from(leads).where(eq(leads.status, "paused"));
    }),

    // Manually process a lead through the agent pipeline
    processLead: tenantAdminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database connection failed");

        const tenantId = ctx.user?.tenantId;
        if (!tenantId) throw new Error("Tenant context required");

        // Get lead
        const result = await db.select().from(leads).where(eq(leads.id, input.id)).limit(1);
        if (result.length === 0) throw new Error("Lead not found");

        const lead = result[0];

        // Verify tenant access
        if (lead.tenantId !== tenantId) throw new Error("Unauthorized");

        // Process through agent pipeline
        const pipelineResult = await processLeadPipeline(lead);

        if (!pipelineResult.success) {
          throw new Error(pipelineResult.error || "Pipeline processing failed");
        }

        return {
          success: true,
          leadId: lead.id,
          category: pipelineResult.data,
        };
      }),

    // Update lead data (for admin manual fixes)
    update: masterAdminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        email: z.string().optional(),
        phone: z.string().optional(),
        message: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database connection failed");

        const updateData: any = {};
        if (input.name !== undefined) updateData.name = input.name;
        if (input.email !== undefined) updateData.email = input.email;
        if (input.phone !== undefined) updateData.phone = input.phone;
        if (input.message !== undefined) updateData.message = input.message;

        await db.update(leads).set(updateData).where(eq(leads.id, input.id));

        return { success: true };
      }),

    // Resolve a paused lead (manual intervention)
    resolvePaused: masterAdminProcedure
      .input(z.object({ leadId: z.number(), resolutionNotes: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database connection failed");

        // Update lead status
        await db.update(leads).set({ status: "categorized" }).where(eq(leads.id, input.leadId));

        return { success: true };
      }),
  }),

  /**
   * REPAIR SYSTEM - Hidden Auditor Agent
   */
  repairSystem: router({
    // Run REPAIR SYSTEM diagnostic and auto-repair
    run: masterAdminProcedure.mutation(async ({ ctx }) => {
      const result = await runRepairSystem();
      
      // Create alert for repair results
      await createRepairAlert(result, ctx.user!.id);
      
      return result;
    }),
  }),

  /**
   * SYSTEM ALERTS & MONITORING
   */
  alerts: router({
    // Get system alerts
    list: masterAdminProcedure
      .input(z.object({ limit: z.number().default(50) }).optional())
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];

        return db.select().from(systemAlerts).limit(input?.limit || 50);
      }),

    // Mark alert as read
    markRead: masterAdminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database connection failed");

        await db.update(systemAlerts).set({ isRead: true }).where(eq(systemAlerts.id, input.id));

        return { success: true };
      }),
  }),

  /**
   * TENANT ADMIN OPERATIONS
   */
  tenantAdmin: router({
    // Get current tenant info (for Tenant Admin)
    getTenant: tenantAdminProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return null;

      const tenantId = ctx.user?.tenantId;
      if (!tenantId) return null;

      const result = await db.select().from(tenants).where(eq(tenants.id, tenantId)).limit(1);
      return result.length > 0 ? result[0] : null;
    }),

    // Get tenant users
    getUsers: tenantAdminProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];

      const tenantId = ctx.user?.tenantId;
      if (!tenantId) return [];

      return db.select().from(users).where(eq(users.tenantId, tenantId));
    }),

    // Get tenant statistics
    getStats: tenantAdminProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return null;

      const tenantId = ctx.user?.tenantId;
      if (!tenantId) return null;

      const allLeads = await db.select().from(leads).where(eq(leads.tenantId, tenantId));

      return {
        totalLeads: allLeads.length,
        emergencyLeads: allLeads.filter((l) => l.category === "emergency").length,
        followUpLeads: allLeads.filter((l) => l.category === "follow_up").length,
        spamLeads: allLeads.filter((l) => l.category === "spam").length,
        pausedLeads: allLeads.filter((l) => l.status === "paused").length,
      };
    }),
  })
});

export type AppRouter = typeof appRouter;
