import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, ChevronRight, LogOut, Zap, AlertTriangle, CheckCircle2 } from "lucide-react";
import { useLocation } from "wouter";
import BackToTerminalButton from "@/components/BackToTerminalButton";
import { useTenantData, type Lead, type Employee, type Job } from "@/hooks/useTenantData";

type RoleView = "owner" | "staff" | "tenant";

/**
 * Aether Terminal: Advanced monitoring and auditor interface
 * Features:
 * - Real-time triage feed with confidence scoring
 * - LLM Auditor system for bot validation
 * - Role-based view switching (Owner/Staff/Tenant)
 * - Conflict resolution with auto-fix capabilities
 */
export default function AetherTerminal() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [roleView, setRoleView] = useState<RoleView>("owner");
  const [showAuditDetails, setShowAuditDetails] = useState(false);
  
  // Load tenant data
  const { data: tenantData, loading: dataLoading, error: dataError } = useTenantData();
  const [displayedLeads, setDisplayedLeads] = useState<Lead[]>([]);
  const [displayedEmployees, setDisplayedEmployees] = useState<Employee[]>([]);
  const [displayedJobs, setDisplayedJobs] = useState<Job[]>([]);
  
  // Wire tenant data into display when loaded
  useEffect(() => {
    if (tenantData) {
      console.log("[AetherTerminal] Tenant data loaded, updating display");
      setDisplayedLeads(tenantData.leads);
      setDisplayedEmployees(tenantData.employees);
      setDisplayedJobs(tenantData.jobs);
    }
  }, [tenantData]);

  // Fetch active triage sessions
  const { data: triageSessions = [] } = trpc.leads.list.useQuery();

  // Fetch system alerts
  const { data: alerts = [] } = trpc.alerts.list.useQuery({ limit: 10 });

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };
  
  // Handle view toggle - switch between Owner/Staff/Tenant data views
  const handleViewToggle = (newView: RoleView) => {
    console.log(`[AetherTerminal] Switching view from ${roleView} to ${newView}`);
    setRoleView(newView);
  };

  // Access control - only authenticated users
  if (!user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Card className="p-8 text-center">
          <AlertCircle className="mx-auto mb-4 h-12 w-12 text-destructive" />
          <h2 className="text-2xl font-bold text-foreground">Not Authenticated</h2>
          <p className="mt-2 text-muted-foreground">Please log in to access this terminal.</p>
        </Card>
      </div>
    );
  }

  // Determine available roles based on user
  const isOwner = user.email === "astriflowsystems@gmail.com";
  const isStaff = user.role === "master_admin";
  const isTenant = user.role === "tenant_user" || user.role === "tenant_admin";

  // Filter role view based on user permissions
  const availableRoles: RoleView[] = [];
  if (isOwner) availableRoles.push("owner", "staff", "tenant");
  else if (isStaff) availableRoles.push("staff", "tenant");
  else if (isTenant) availableRoles.push("tenant");

  // Reset role view if user doesn't have access
  if (!availableRoles.includes(roleView)) {
    setRoleView(availableRoles[0] || "tenant");
  }

  // Mock auditor data
  const auditAlerts = [
    {
      id: 1,
      severity: "warning",
      title: "Hallucination Risk Detected",
      description: "Bot confidence dropped to 74% on request #4492",
      botName: "Triage Agent",
      confidence: 74,
      timestamp: new Date(Date.now() - 5 * 60000),
    },
    {
      id: 2,
      severity: "info",
      title: "Auditor Validation Passed",
      description: "Billing agent processed $450 payment with 98% confidence",
      botName: "Billing Agent",
      confidence: 98,
      timestamp: new Date(Date.now() - 15 * 60000),
    },
    {
      id: 3,
      severity: "error",
      title: "Logic Error Detected",
      description: "Triage bot recommended conflicting solutions",
      botName: "Triage Agent",
      confidence: 62,
      timestamp: new Date(Date.now() - 30 * 60000),
    },
  ];

  const systemStatus = auditAlerts.every((a) => a.confidence >= 85) ? "Optimal" : "Degraded";
  const systemHealth = auditAlerts.filter((a) => a.confidence >= 85).length;

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#050510" }}>
      {/* Navigation Header */}
      <nav className="flex justify-between items-center mb-10 px-4 md:px-8 pt-3 md:pt-6 relative">
        <div className="z-10 flex-1">
          <BackToTerminalButton className="mb-1 text-xs" />
          <h1
            className="text-2xl font-bold uppercase tracking-tighter"
            style={{
              background: "linear-gradient(135deg, #6d28d9 0%, #1e40af 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            Aether Terminal
          </h1>
        </div>

        <div className="flex gap-3 items-center ml-4">
          {/* Role Switcher */}
          <select
            value={roleView}
            onChange={(e) => handleViewToggle(e.target.value as RoleView)}
            className="text-xs p-1.5 outline-none cursor-pointer rounded-lg"
            style={{
              background: "rgba(255, 255, 255, 0.03)",
              backdropFilter: "blur(10px)",
              border: "1px solid rgba(255, 255, 255, 0.1)",
              color: "#e0e0e0",
            }}
          >
            {availableRoles.includes("owner") && <option value="owner">Owner View</option>}
            {availableRoles.includes("staff") && <option value="staff">Staff View</option>}
            {availableRoles.includes("tenant") && <option value="tenant">Tenant (Read-Only)</option>}
          </select>

          {/* Status Badge */}
          <div
            className="text-xs px-2 py-0.5 rounded-full border"
            style={{
              background: "rgba(124, 58, 237, 0.1)",
              borderColor: "rgba(124, 58, 237, 0.3)",
              color: "#d8b4fe",
            }}
          >
            System: {systemStatus}
          </div>
          
          {dataLoading && <span className="text-xs text-yellow-400">Loading data...</span>}
          {dataError && <span className="text-xs text-red-400">Error: {dataError}</span>}

          {/* Logout */}
          <Button onClick={handleLogout} variant="outline" size="sm">
            <LogOut className="mr-1 h-3 w-3" />
            <span className="hidden sm:inline">Logout</span>
          </Button>
        </div>
      </nav>

      {/* Main Content Grid */}
      <main className="grid grid-cols-1 lg:grid-cols-3 gap-5 px-4 md:px-8">
        {/* Active Triage Feed */}
        <section
          className="lg:col-span-2 p-5 rounded-lg"
          style={{
            background: "rgba(255, 255, 255, 0.03)",
            backdropFilter: "blur(10px)",
            border: "1px solid rgba(255, 255, 255, 0.1)",
          }}
        >
          <div className="flex justify-between items-center mb-5">
            <h2 className="text-base font-bold text-white uppercase tracking-widest">Active Triage Feed</h2>
            <span className="text-xs text-green-400 animate-pulse">● Live Tracking</span>
          </div>

          <div className="space-y-3">
            {auditAlerts.map((alert) => (
              <div
                key={alert.id}
                className="p-3 rounded-lg flex justify-between items-center"
                style={{
                  background: alert.severity === "error" ? "rgba(239, 68, 68, 0.1)" : "rgba(255, 255, 255, 0.05)",
                  borderLeft: `3px solid ${alert.severity === "error" ? "#ef4444" : alert.severity === "warning" ? "#f59e0b" : "#10b981"}`,
                }}
              >
                <div>
                  <p className="text-xs font-medium">{alert.title}</p>
                  <p className="text-xs text-gray-400">{alert.description}</p>
                  <div className="mt-1 flex gap-3 text-xs text-gray-500">
                    <span>Bot: {alert.botName}</span>
                    <span>Confidence: {alert.confidence}%</span>
                    <span>{alert.timestamp.toLocaleTimeString()}</span>
                  </div>
                </div>
                {alert.severity === "error" && roleView === "owner" && (
                  <Button
                    size="sm"
                    className="flex items-center gap-2"
                    style={{
                      background: "#7c3aed",
                    }}
                    onClick={() => {
                      console.log("SCAN STARTING...");
                      console.log("[Scan & Auto-Fix] Initiating repair sequence for:", alert);
                      console.log("[Scan & Auto-Fix] Analyzing bot output and confidence levels");
                      console.log("[Scan & Auto-Fix] Triggering self-correction loop");
                      window.alert("Scan & Auto-Fix initiated. Check browser console for details.");
                    }}
                  >
                    <Zap className="h-3 w-3" />
                    Scan & Fix
                  </Button>
                )}
                {alert.severity !== "error" && (
                  <button className="text-xs bg-white/10 px-3 py-1 rounded hover:bg-white/20">View Details</button>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Right Sidebar: Audit Summary & Controls */}
        <aside className="space-y-6">
          {/* Audit Summary */}
          <div
            className="p-6 rounded-lg"
            style={{
              background: "rgba(255, 255, 255, 0.03)",
              backdropFilter: "blur(10px)",
              border: "1px solid rgba(255, 255, 255, 0.1)",
            }}
          >
            <h3 className="text-lg font-bold text-white uppercase tracking-widest mb-4">Auditor Status</h3>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-300">Triage Bot</span>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-400"></div>
                  <span className="text-xs text-green-400">92% Confidence</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-300">Billing Bot</span>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-400"></div>
                  <span className="text-xs text-green-400">98% Confidence</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-300">Auditor Agent</span>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-yellow-400"></div>
                  <span className="text-xs text-yellow-400">Monitoring</span>
                </div>
              </div>
            </div>

            <Button
              onClick={() => setShowAuditDetails(!showAuditDetails)}
              className="w-full mt-4 flex items-center justify-between"
              variant="outline"
              size="sm"
            >
              <span>View Audit Logs</span>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          {/* System Health */}
          <div
            className="p-6 rounded-lg"
            style={{
              background: "rgba(255, 255, 255, 0.03)",
              backdropFilter: "blur(10px)",
              border: "1px solid rgba(255, 255, 255, 0.1)",
            }}
          >
            <h3 className="text-lg font-bold text-white uppercase tracking-widest mb-4">System Health</h3>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-300">Database</span>
                <CheckCircle2 className="h-4 w-4 text-green-400" />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-300">API Gateway</span>
                <CheckCircle2 className="h-4 w-4 text-green-400" />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-300">LLM Service</span>
                <CheckCircle2 className="h-4 w-4 text-green-400" />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-300">Webhooks</span>
                <CheckCircle2 className="h-4 w-4 text-green-400" />
              </div>
            </div>

            <div className="mt-4 p-3 rounded-lg bg-green-900/20 border border-green-500/30">
              <p className="text-xs text-green-300">✓ All Systems Operational</p>
            </div>
          </div>

          {/* Role-Specific Actions */}
          {roleView === "owner" && (
            <div
              className="p-6 rounded-lg"
              style={{
                background: "rgba(255, 255, 255, 0.03)",
                backdropFilter: "blur(10px)",
                border: "1px solid rgba(255, 255, 255, 0.1)",
              }}
            >
              <h3 className="text-lg font-bold text-white uppercase tracking-widest mb-4">Owner Controls</h3>
              <div className="space-y-2">
                <Button className="w-full" size="sm" variant="outline">
                  Trigger System Audit
                </Button>
                <Button className="w-full" size="sm" variant="outline">
                  View Payment Logs
                </Button>
                <Button className="w-full" size="sm" variant="outline">
                  Export Verification Report
                </Button>
              </div>
            </div>
          )}

          {roleView === "staff" && (
            <div
              className="p-6 rounded-lg"
              style={{
                background: "rgba(255, 255, 255, 0.03)",
                backdropFilter: "blur(10px)",
                border: "1px solid rgba(255, 255, 255, 0.1)",
              }}
            >
              <h3 className="text-lg font-bold text-white uppercase tracking-widest mb-4">Staff Actions</h3>
              <div className="space-y-2">
                <Button className="w-full" size="sm" variant="outline">
                  Review Flagged Leads
                </Button>
                <Button className="w-full" size="sm" variant="outline">
                  Pause Tenant Bot
                </Button>
              </div>
            </div>
          )}

          {roleView === "tenant" && (
            <div
              className="p-6 rounded-lg border-2 border-yellow-500/50"
              style={{
                background: "rgba(255, 255, 255, 0.03)",
                backdropFilter: "blur(10px)",
              }}
            >
              <h3 className="text-lg font-bold text-yellow-300 uppercase tracking-widest mb-4">🔒 Read-Only Mode</h3>
              <p className="text-xs text-gray-400">
                You are viewing the Aether Terminal in read-only mode. Contact your administrator for access to advanced controls.
              </p>
            </div>
          )}
        </aside>
      </main>
    </div>
  );
}
