import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface TerminationRequestDialogProps {
  tenantId: number;
  tenantName: string;
  onClose: () => void;
  onSuccess: () => void;
}

export default function TerminationRequestDialog({
  tenantId,
  tenantName,
  onClose,
  onSuccess,
}: TerminationRequestDialogProps) {
  const [reasoning, setReasoning] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const requestTermination = trpc.tenants.terminate.useMutation({
    onSuccess: () => {
      toast.success("Termination request submitted to Owner for approval");
      setReasoning("");
      onSuccess();
      onClose();
    },
    onError: (error: any) => {
      toast.error(`Failed to submit request: ${error?.message || "Unknown error"}`);
    },
    onSettled: () => {
      setIsSubmitting(false);
    },
  });

  const handleSubmit = async () => {
    if (!reasoning.trim()) {
      toast.error("Please provide a reason for termination");
      return;
    }

    setIsSubmitting(true);
    await requestTermination.mutateAsync({
      id: tenantId,
      reason: reasoning.trim(),
    });
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <Card className="border-border bg-card w-full max-w-md p-6">
        <div className="mb-4 flex items-center gap-3">
          <AlertTriangle className="h-6 w-6 text-yellow-500" />
          <h2 className="text-xl font-bold text-foreground">Request Termination</h2>
        </div>

        <p className="mb-4 text-sm text-muted-foreground">
          You are requesting termination for <span className="font-semibold text-foreground">{tenantName}</span>. This request will be sent to the Owner for final approval.
        </p>

        <div className="mb-4">
          <label className="mb-2 block text-sm font-medium text-foreground">
            Reason for Termination
          </label>
          <textarea
            value={reasoning}
            onChange={(e) => setReasoning(e.target.value)}
            placeholder="Explain why this tenant should be terminated..."
            className="h-32 w-full rounded-lg border border-border bg-background p-3 text-foreground placeholder-muted-foreground focus:border-primary focus:outline-none"
          />
          <p className="mt-1 text-xs text-muted-foreground">
            {reasoning.length}/500 characters
          </p>
        </div>

        <div className="flex gap-3">
          <Button
            onClick={onClose}
            disabled={isSubmitting}
            variant="outline"
            className="flex-1"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting || !reasoning.trim()}
            className="flex-1 bg-yellow-600 hover:bg-yellow-700"
          >
            {isSubmitting ? "Submitting..." : "Submit Request"}
          </Button>
        </div>
      </Card>
    </div>
  );
}
