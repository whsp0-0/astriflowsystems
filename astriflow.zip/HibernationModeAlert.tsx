import { AlertCircle, Power } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface HibernationModeAlertProps {
  subscriptionStatus: string | null;
  onReactivate?: () => void;
}

export default function HibernationModeAlert({ subscriptionStatus, onReactivate }: HibernationModeAlertProps) {
  const isHibernating = subscriptionStatus === "canceled" || subscriptionStatus === "unpaid";

  if (!isHibernating) {
    return null;
  }

  return (
    <Card className="border-yellow-500/30 bg-yellow-500/5 p-4">
      <div className="flex items-start gap-4">
        <Power className="h-5 w-5 flex-shrink-0 text-yellow-600" />
        <div className="flex-1">
          <h3 className="font-semibold text-foreground">Hibernation Mode Active</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            {subscriptionStatus === "unpaid"
              ? "Your subscription payment is overdue. AI lead processing is paused."
              : "Your subscription has been canceled. AI lead processing is paused."}
          </p>
          <p className="mt-2 text-xs text-muted-foreground">
            Reactivate your subscription to resume automatic lead categorization and processing.
          </p>
          {onReactivate && (
            <Button onClick={onReactivate} size="sm" className="mt-3 bg-yellow-600 hover:bg-yellow-700">
              Reactivate Subscription
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}
