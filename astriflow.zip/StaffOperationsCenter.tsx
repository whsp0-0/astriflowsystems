import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, Users, Activity, CheckCircle2, Clock, LogOut, Pause, Play } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import BackToTerminalButton from "@/components/BackToTerminalButton";

export default function StaffOperationsCenter() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [showLeadQueue, setShowLeadQueue] = useState(false);
  const [showTenantList, setShowTenantList] = useState(false);
  const [pausedTenantIds, setPausedTenantIds] = useState<Set<number>>(new Set());

  // Fetch leads that need review
  const { data: leads, isLoading: leadsLoading } = trpc.leads.list.useQuery();
  const flaggedLeads = leads?.filter((l) => l.status === "paused") || [];

  // Fetch all tenants (staff can see all tenants but cannot modify)
  const { data: tenants = [] } = trpc.tenants.list.useQuery();

  const handleLogout = async () => {
    await logout();
    setLocation("/");
    toast.success("Logged out successfully");
  };

  // Staff Operations Center is for staff and admin users (not owner)
  // Owner is routed directly to CommandCenter in App.tsx
  if (!user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Card className="p-8 text-center">
          <AlertCircle className="mx-auto mb-4 h-12 w-12 text-destructive" />
          <h2 className="text-2xl font-bold text-foreground">Not Authenticated</h2>
          <p className="mt-2 text-muted-foreground">Please log in to access this page.</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <BackToTerminalButton />
          <div>
            <h1 className="text-3xl font-bold text-foreground">ASTRIflow Staff Operations Center</h1>
            <p className="mt-1 text-sm text-muted-foreground">Lead triage and system monitoring</p>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">Welcome, {user?.name}</span>
            <Button onClick={handleLogout} variant="outline" size="sm">
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="mx-auto max-w-7xl px-6 py-8">
        {/* Quick Stats */}
        <div className="mb-8 grid grid-cols-1 gap-4 md:grid-cols-3">
          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Flagged Leads</p>
                <p className="mt-2 text-3xl font-bold text-foreground">{flaggedLeads.length}</p>
              </div>
              <AlertCircle className="h-12 w-12 text-yellow-500" />
            </div>
          </Card>

          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Processes</p>
                <p className="mt-2 text-3xl font-bold text-foreground">3</p>
              </div>
              <Activity className="h-12 w-12 text-green-500" />
            </div>
          </Card>

          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">System Status</p>
                <p className="mt-2 text-lg font-bold text-green-500">Operational</p>
              </div>
              <CheckCircle2 className="h-12 w-12 text-green-500" />
            </div>
          </Card>
        </div>

        {/* Lead Review Queue */}
        <Card className="border-border bg-card p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-xl font-bold text-foreground">Lead Review Queue</h2>
            <Button onClick={() => setShowLeadQueue(!showLeadQueue)} variant="outline" size="sm">
              {showLeadQueue ? "Hide" : "Show"} Queue
            </Button>
          </div>

          {showLeadQueue && (
            <div className="space-y-4">
              {leadsLoading ? (
                <p className="text-muted-foreground">Loading leads...</p>
              ) : flaggedLeads.length === 0 ? (
                <p className="text-muted-foreground">No flagged leads at this time.</p>
              ) : (
                flaggedLeads.map((lead) => (
                  <div key={lead.id} className="flex items-center justify-between rounded-lg border border-border bg-background p-4">
                    <div>
                      <p className="font-medium text-foreground">{lead.name || "Unknown"}</p>
                      <p className="text-sm text-muted-foreground">{lead.email || lead.phone || "No contact info"}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Review
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </Card>

        {/* Consolidated Tenant List */}
        <Card className="border-border bg-card p-6 mt-8">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
              <Users className="h-5 w-5" />
              Consolidated Tenant List
            </h2>
            <Button onClick={() => setShowTenantList(!showTenantList)} variant="outline" size="sm">
              {showTenantList ? "Hide" : "Show"} Tenants
            </Button>
          </div>

          {showTenantList && (
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {tenants.length === 0 ? (
                <p className="text-muted-foreground">No tenants found.</p>
              ) : (
                <div className="grid grid-cols-1 gap-2">
                  {tenants.map((tenant) => (
                    <div
                      key={tenant.id}
                      className="flex items-center justify-between rounded-lg border border-border bg-background p-4"
                    >
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{tenant.name}</p>
                        <p className="text-xs text-muted-foreground">{tenant.email}</p>
                        <div className="mt-2 flex gap-4 text-xs text-muted-foreground">
                          <span>Status: {tenant.status}</span>
                          <span>Subscription: {tenant.subscriptionStatus}</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const newPaused = new Set(pausedTenantIds);
                            if (newPaused.has(tenant.id)) {
                              newPaused.delete(tenant.id);
                              toast.success(`Resumed ${tenant.name}`);
                            } else {
                              newPaused.add(tenant.id);
                              toast.success(`Paused ${tenant.name}`);
                            }
                            setPausedTenantIds(newPaused);
                          }}
                          className="flex items-center gap-2"
                        >
                          {pausedTenantIds.has(tenant.id) ? (
                            <>
                              <Play className="h-4 w-4" />
                              Resume
                            </>
                          ) : (
                            <>
                              <Pause className="h-4 w-4" />
                              Pause
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
          <p className="mt-4 text-xs text-muted-foreground italic">
            ℹ️ Staff can view and pause tenants but cannot delete or access financial data.
          </p>
        </Card>

        {/* System Monitoring */}
        <Card className="border-border bg-card p-6 mt-8">
          <h2 className="mb-4 text-xl font-bold text-foreground">System Monitoring</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Database Connection</span>
              <span className="text-sm font-medium text-green-500">Connected</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">AI Agent Network</span>
              <span className="text-sm font-medium text-green-500">Operational</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Webhook Endpoint</span>
              <span className="text-sm font-medium text-green-500">Active</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
