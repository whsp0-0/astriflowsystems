import { describe, it, expect, vi, beforeEach } from "vitest";
import { leads } from "../drizzle/schema";
import type { Lead } from "../drizzle/schema";

/**
 * AGENT TESTS
 * Note: These are unit tests that mock the LLM and database interactions
 * In production, integration tests would verify end-to-end behavior
 */

describe("Agent Orchestration", () => {
  // Mock lead data
  const mockLead: Lead = {
    id: 1,
    tenantId: 1,
    sourceChannel: "instagram_dm",
    sourceId: "ig_123",
    name: "John Smith",
    email: "john@example.com",
    phone: "+1-555-0123",
    message: "My AC is not working. It's 95 degrees outside and I need help ASAP!",
    category: "uncategorized",
    categoryConfidence: null,
    categoryReason: null,
    categoryAuditedAt: null,
    categoryAuditedBy: null,
    selfCorrectionTriggered: false,
    selfCorrectionReason: null,
    selfCorrectionAttempts: 0,
    status: "pending",
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockLeadMissingPhone: Lead = {
    ...mockLead,
    id: 2,
    phone: null,
    message: "I need HVAC service",
  };

  const mockLeadSpam: Lead = {
    ...mockLead,
    id: 3,
    message: "Click here to win free money! Best deals on furniture!",
  };

  describe("Lead Categorization Logic", () => {
    it("should identify emergency leads with high confidence", () => {
      const emergencyKeywords = ["heat", "ac", "cooling", "heating", "emergency", "urgent", "broken", "failure"];
      const messageText = mockLead.message.toLowerCase();
      const hasEmergencyKeywords = emergencyKeywords.some((kw) => messageText.includes(kw));

      expect(hasEmergencyKeywords).toBe(true);
      expect(mockLead.message).toContain("AC");
      expect(mockLead.message).toContain("ASAP");
    });

    it("should detect spam messages", () => {
      const spamKeywords = ["click", "free", "win", "deal", "offer", "limited"];
      const messageText = mockLeadSpam.message.toLowerCase();
      const hasSpamKeywords = spamKeywords.some((kw) => messageText.includes(kw));

      expect(hasSpamKeywords).toBe(true);
    });

    it("should flag leads missing phone number for self-correction", () => {
      const issues: string[] = [];

      if (!mockLeadMissingPhone.phone) {
        issues.push("Missing phone number - cannot verify lead authenticity");
      }

      expect(issues).toContain("Missing phone number - cannot verify lead authenticity");
      expect(issues.length).toBeGreaterThan(0);
    });

    it("should flag leads missing email", () => {
      const leadMissingEmail = { ...mockLead, email: null };
      const issues: string[] = [];

      if (!leadMissingEmail.email) {
        issues.push("Missing email - incomplete contact information");
      }

      expect(issues).toContain("Missing email - incomplete contact information");
    });
  });

  describe("Self-Correction Loop Triggers", () => {
    it("should trigger self-correction when phone is missing", () => {
      const issues: string[] = [];

      if (!mockLeadMissingPhone.phone) {
        issues.push("Missing phone number");
      }

      const needsSelfCorrection = issues.length > 0;
      expect(needsSelfCorrection).toBe(true);
    });

    it("should trigger self-correction for low-confidence emergency categorization", () => {
      const lowConfidenceLead = { ...mockLead, categoryConfidence: 0.45 };
      const emergencyKeywords = ["heat", "ac", "cooling", "heating", "emergency", "urgent", "broken", "failure"];
      const messageText = lowConfidenceLead.message.toLowerCase();
      const hasEmergencyKeywords = emergencyKeywords.some((kw) => messageText.includes(kw));

      const issues: string[] = [];
      const confidence = typeof lowConfidenceLead.categoryConfidence === 'string' 
        ? parseFloat(lowConfidenceLead.categoryConfidence) 
        : lowConfidenceLead.categoryConfidence;

      if (lowConfidenceLead.category === "emergency" && !hasEmergencyKeywords && confidence && confidence < 0.7) {
        issues.push("Emergency categorization has low confidence and lacks emergency keywords");
      }

      // This lead has emergency keywords, so it shouldn't trigger
      expect(issues.length).toBe(0);
    });

    it("should not trigger self-correction for valid leads with all info", () => {
      const issues: string[] = [];

      if (!mockLead.phone) issues.push("Missing phone");
      if (!mockLead.email) issues.push("Missing email");

      const needsSelfCorrection = issues.length > 0;
      expect(needsSelfCorrection).toBe(false);
    });
  });

  describe("Failure Tracking and Master Auditor", () => {
    it("should track consecutive failures correctly", () => {
      const failureTracking: Record<string, number> = {};

      // Simulate 2 consecutive failures
      failureTracking["lead_worker"] = 1;
      failureTracking["lead_worker"] = 2;

      expect(failureTracking["lead_worker"]).toBe(2);
    });

    it("should pause lead after 2 consecutive failures", () => {
      const failureCount = 2;
      const shouldPause = failureCount >= 2;

      expect(shouldPause).toBe(true);
    });

    it("should reset failure counter on success", () => {
      let failureCount = 2;
      failureCount = 0; // Reset on success

      expect(failureCount).toBe(0);
    });

    it("should not pause lead after only 1 failure", () => {
      const failureCount = 1;
      const shouldPause = failureCount >= 2;

      expect(shouldPause).toBe(false);
    });
  });

  describe("Transcript Log Generation", () => {
    it("should create comprehensive transcript with all agent decisions", () => {
      const transcriptLines: string[] = [
        "Lead Worker Agent categorized lead as \"emergency\" with 92.5% confidence.",
        "Safety Critic Agent validated categorization. No issues detected.",
      ];

      const fullTranscript = transcriptLines.join("\n\n");

      expect(fullTranscript).toContain("Lead Worker Agent");
      expect(fullTranscript).toContain("Safety Critic Agent");
      expect(fullTranscript).toContain("emergency");
    });

    it("should include self-correction details in transcript", () => {
      const transcriptLines: string[] = [
        "Lead Worker Agent categorized lead as \"follow_up\" with 65.0% confidence.",
        "Safety Critic Agent detected issues: Missing phone number. Triggering self-correction loop.",
        "Self-Correction Loop: Lead re-categorized as \"emergency\" with 88.0% confidence.",
      ];

      const fullTranscript = transcriptLines.join("\n\n");

      expect(fullTranscript).toContain("Self-Correction Loop");
      expect(fullTranscript).toContain("Missing phone number");
    });

    it("should mark transcript as visible to both Master and Tenant Admin", () => {
      const transcriptVisibility = {
        visibleToMasterAdmin: true,
        visibleToTenantAdmin: true,
      };

      expect(transcriptVisibility.visibleToMasterAdmin).toBe(true);
      expect(transcriptVisibility.visibleToTenantAdmin).toBe(true);
    });
  });

  describe("Multi-Tenant Isolation", () => {
    it("should enforce tenant isolation in lead queries", () => {
      const lead1 = { ...mockLead, tenantId: 1 };
      const lead2 = { ...mockLead, id: 2, tenantId: 2 };

      expect(lead1.tenantId).not.toBe(lead2.tenantId);
      expect(lead1.tenantId).toBe(1);
      expect(lead2.tenantId).toBe(2);
    });

    it("should ensure agent logs are tenant-scoped", () => {
      const log1 = { tenantId: 1, leadId: 1, agentType: "lead_worker" as const };
      const log2 = { tenantId: 2, leadId: 2, agentType: "lead_worker" as const };

      expect(log1.tenantId).not.toBe(log2.tenantId);
    });

    it("should ensure paused leads are tenant-scoped", () => {
      const pausedLead1 = { tenantId: 1, leadId: 1 };
      const pausedLead2 = { tenantId: 2, leadId: 2 };

      expect(pausedLead1.tenantId).not.toBe(pausedLead2.tenantId);
    });
  });

  describe("System Alerts", () => {
    it("should create critical alert when lead is paused", () => {
      const alert = {
        alertType: "agent_failure" as const,
        severity: "critical" as const,
        title: "Critical: Lead Paused Due to Agent Failures",
        message: "Lead #1 has been paused. lead_worker failed 2 consecutive times.",
      };

      expect(alert.severity).toBe("critical");
      expect(alert.alertType).toBe("agent_failure");
      expect(alert.title).toContain("Lead Paused");
    });

    it("should include related data in alert", () => {
      const alert = {
        alertType: "agent_failure" as const,
        relatedData: {
          agentType: "lead_worker",
          failureCount: 2,
        },
      };

      expect(alert.relatedData.failureCount).toBe(2);
      expect(alert.relatedData.agentType).toBe("lead_worker");
    });
  });

  describe("Categorization Confidence Levels", () => {
    it("should accept confidence between 0 and 1", () => {
      const validConfidences = [0, 0.5, 0.75, 0.99, 1];

      for (const conf of validConfidences) {
        expect(conf).toBeGreaterThanOrEqual(0);
        expect(conf).toBeLessThanOrEqual(1);
      }
    });

    it("should flag low confidence categorizations", () => {
      const lowConfidence = 0.45;
      const threshold = 0.7;

      expect(lowConfidence < threshold).toBe(true);
    });

    it("should accept high confidence categorizations", () => {
      const highConfidence = 0.92;
      const threshold = 0.7;

      expect(highConfidence >= threshold).toBe(true);
    });
  });
});
