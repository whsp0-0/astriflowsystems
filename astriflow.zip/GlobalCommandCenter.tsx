import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Activity, AlertTriangle, Building2, TrendingUp, LogOut } from "lucide-react";
import { useLocation } from "wouter";

export default function GlobalCommandCenter() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const { data: tenants = [] } = trpc.tenants.list.useQuery();
  const { data: leads = [] } = trpc.leads.list.useQuery();

  const activeTenants = tenants.filter((t) => t.subscriptionStatus === "active").length;
  const totalLeads = leads.length;
  const aiUptime = activeTenants > 0 ? 100 : 0;

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Global Command Center</h1>
              <p className="mt-1 text-sm text-muted-foreground">System-wide oversight and real-time metrics</p>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">Welcome, {user?.name}</span>
              <Button onClick={handleLogout} variant="outline" size="sm">
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Metrics Grid */}
        <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {/* Total Leads */}
          <Card className="border-border bg-card p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Leads</p>
                <p className="mt-2 text-3xl font-bold text-foreground">{totalLeads}</p>
                <p className="mt-1 text-xs text-muted-foreground">All processed leads</p>
              </div>
              <Activity className="h-8 w-8 text-primary/50" />
            </div>
          </Card>

          {/* AI Uptime */}
          <Card className="border-border bg-card p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">AI Uptime</p>
                <p className="mt-2 text-3xl font-bold text-foreground">{aiUptime}%</p>
                <p className="mt-1 text-xs text-muted-foreground">{activeTenants} agents active</p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-500/50" />
            </div>
          </Card>

          {/* Active Tenants */}
          <Card className="border-border bg-card p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Tenants</p>
                <p className="mt-2 text-3xl font-bold text-foreground">{activeTenants}</p>
                <p className="mt-1 text-xs text-muted-foreground">of {tenants.length} total</p>
              </div>
              <Building2 className="h-8 w-8 text-blue-500/50" />
            </div>
          </Card>

          {/* System Health */}
          <Card className="border-border bg-card p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">System Health</p>
                <p className="mt-2 text-3xl font-bold text-foreground">Optimal</p>
                <p className="mt-1 text-xs text-muted-foreground">All systems operational</p>
              </div>
              <Activity className="h-8 w-8 text-green-500/50" />
            </div>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mb-8 grid grid-cols-1 gap-4 lg:grid-cols-2">
          <Card className="border-border bg-card p-6">
            <h3 className="mb-4 text-lg font-semibold text-foreground">Quick Actions</h3>
            <div className="space-y-2">
              <Button
                onClick={() => navigate("/command-center")}
                variant="outline"
                className="w-full justify-start"
              >
                Go to Master Command Center
              </Button>
              <Button
                onClick={() => navigate("/master-admin")}
                variant="outline"
                className="w-full justify-start"
              >
                View Master Dashboard
              </Button>
            </div>
          </Card>

          <Card className="border-border bg-card p-6">
            <h3 className="mb-4 text-lg font-semibold text-foreground">System Status</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Database</span>
                <span className="inline-flex items-center rounded-full bg-green-500/20 px-2 py-1 text-xs font-medium text-green-400">
                  Online
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Webhooks</span>
                <span className="inline-flex items-center rounded-full bg-green-500/20 px-2 py-1 text-xs font-medium text-green-400">
                  Active
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Stripe</span>
                <span className="inline-flex items-center rounded-full bg-green-500/20 px-2 py-1 text-xs font-medium text-green-400">
                  Connected
                </span>
              </div>
            </div>
          </Card>
        </div>

        {/* Alerts Section */}
        {tenants.some((t) => t.status === "tombstone") && (
          <Card className="border-yellow-500/30 bg-yellow-500/5 p-6">
            <div className="flex items-start gap-4">
              <AlertTriangle className="h-5 w-5 flex-shrink-0 text-yellow-500" />
              <div>
                <h4 className="font-semibold text-foreground">Pending Actions</h4>
                <p className="mt-1 text-sm text-muted-foreground">
                  {tenants.filter((t) => t.status === "tombstone").length} tenant(s) in tombstone status awaiting restoration or permanent deletion.
                </p>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
