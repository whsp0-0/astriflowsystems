# ASTRIflow - Setup & Deployment Guide

## Overview

ASTRIflow is a **Zero-Touch** multi-tenant SaaS platform for HVAC lead automation. It features a self-healing multi-agent network that automatically categorizes leads, audits decisions, and alerts the Master Admin of any issues.

## Architecture

### Multi-Tenant Database
- **Master Admin**: System-wide access to all tenants and operations
- **Tenant Admin**: Per-tenant access to their HVAC company's leads and data
- **Tenant User**: Limited access within their tenant

### Multi-Agent Pipeline
1. **Lead Worker Agent**: Receives incoming leads via webhook, categorizes using Gemini LLM (Emergency, Follow-up, Spam)
2. **Safety Critic Agent**: Audits every categorization, detects mismatches and missing contact info, triggers self-correction
3. **Master Auditor Agent**: Monitors sub-agent health, pauses leads after 2 consecutive failures, alerts Master Admin

### Core Features
- **One-Click Client Setup**: Master Admin adds new HVAC business → auto-provisions database entries + Stripe subscription link
- **Automated Transcript Logs**: Full proof-of-work documentation for every lead
- **Dark-Mode Space UI**: High-end minimalist interface with purple/blue aesthetic
- **Instagram/DM Webhook**: Automatic lead ingestion from social channels
- **Stripe Integration**: Automated subscription management and billing

## Prerequisites

- Node.js 22.13.0+
- MySQL/TiDB database
- Stripe account (test or live)
- Gemini API key (for LLM integration)
- Instagram Business Account (for webhook setup)

## Installation

### 1. Clone & Install Dependencies

```bash
cd /home/ubuntu/astriflow
pnpm install
```

### 2. Environment Configuration

The following environment variables are automatically injected by Manus:

```
DATABASE_URL              # MySQL/TiDB connection string
JWT_SECRET                # Session cookie signing secret
VITE_APP_ID              # Manus OAuth application ID
OAUTH_SERVER_URL         # Manus OAuth backend URL
VITE_OAUTH_PORTAL_URL    # Manus OAuth login portal URL
BUILT_IN_FORGE_API_URL   # Manus built-in APIs (LLM, storage, etc.)
BUILT_IN_FORGE_API_KEY   # Bearer token for server-side API access
VITE_FRONTEND_FORGE_API_KEY  # Bearer token for frontend API access
STRIPE_SECRET_KEY        # Stripe API secret key
VITE_STRIPE_PUBLISHABLE_KEY  # Stripe publishable key
STRIPE_WEBHOOK_SECRET    # Stripe webhook signature secret
```

### 3. Database Setup

The database schema is automatically applied on first run. To manually apply migrations:

```bash
pnpm db:push
```

This will:
- Generate migration SQL from `drizzle/schema.ts`
- Apply all pending migrations to the database

## Running the Application

### Development Mode

```bash
pnpm dev
```

The dev server will start on `http://localhost:3000` with:
- Hot module reloading (HMR)
- TypeScript type checking
- Express backend + Vite frontend

### Production Build

```bash
pnpm build
pnpm start
```

## API Endpoints

### Authentication
- `POST /api/oauth/callback` - OAuth callback handler
- `GET /api/trpc/auth.me` - Get current user
- `POST /api/trpc/auth.logout` - Logout

### Webhook Ingestion
- `POST /api/webhooks/instagram` - Instagram/DM lead ingestion
- `POST /api/webhooks/leads` - Generic lead ingestion
- `GET /api/webhooks/health` - Health check

### tRPC Procedures
All business logic is exposed via tRPC at `/api/trpc`:

**Tenant Management** (Master Admin only):
- `tenants.list` - List all tenants
- `tenants.create` - Create new tenant + provision database
- `tenants.update` - Update tenant details
- `tenants.generateSubscriptionLink` - Generate Stripe checkout link

**Lead Management** (Tenant Admin):
- `leads.list` - List leads for tenant
- `leads.getDetail` - Get lead with full audit trail
- `leads.getTranscript` - Get transcript log for lead

**System** (Master Admin):
- `system.getAlerts` - Get system alerts
- `system.getPausedLeads` - Get leads paused by Master Auditor
- `system.notifyOwner` - Send notification to Master Admin

## Stripe Setup

### Test Mode (Development)

1. **Claim Sandbox**: Visit https://dashboard.stripe.com/claim_sandbox to activate test environment
2. **Get Keys**: Retrieve test API keys from Stripe Dashboard
3. **Test Card**: Use `4242 4242 4242 4242` for testing
4. **Webhook Setup**: Configure webhook endpoint at `POST /api/stripe/webhook`

### Live Mode (Production)

1. **Complete KYC**: Verify business information with Stripe
2. **Get Live Keys**: Retrieve live API keys
3. **Update Secrets**: Set `STRIPE_SECRET_KEY` and `VITE_STRIPE_PUBLISHABLE_KEY` in Settings → Payment
4. **Enable Webhooks**: Configure production webhook endpoint

## Instagram Webhook Setup

### 1. Create App & Get Credentials

- Go to [Meta Developers](https://developers.facebook.com/)
- Create a new app (type: Business)
- Add Instagram product
- Get App ID and App Secret

### 2. Configure Webhook

- Endpoint URL: `https://your-domain.com/api/webhooks/instagram`
- Verify Token: Set `WEBHOOK_VERIFY_TOKEN` environment variable
- Subscribe to: `messages` event

### 3. Test Webhook

```bash
# Test webhook challenge
curl -X GET "https://your-domain.com/api/webhooks/instagram?mode=subscribe&token=YOUR_VERIFY_TOKEN&challenge=CHALLENGE_STRING"

# Send test lead
curl -X POST "https://your-domain.com/api/webhooks/instagram" \
  -H "Content-Type: application/json" \
  -d '{
    "tenantId": 1,
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+1234567890",
    "message": "My AC is broken",
    "source": "instagram_dm",
    "messageId": "msg_123"
  }'
```

## Testing

### Run Unit Tests

```bash
pnpm test
```

This runs all Vitest tests covering:
- Agent logic (Lead Worker, Safety Critic, Master Auditor)
- Multi-tenant isolation
- Authentication and authorization

### Manual Testing Checklist

- [ ] Master Admin can log in
- [ ] Master Admin can create new tenant via One-Click Setup
- [ ] Stripe checkout link opens successfully
- [ ] Tenant Admin can log in to their tenant
- [ ] Leads appear in Tenant Dashboard after webhook ingestion
- [ ] Lead categorization works (Emergency, Follow-up, Spam)
- [ ] Self-correction loop triggers on missing phone number
- [ ] Master Auditor pauses lead after 2 consecutive failures
- [ ] Master Admin receives alert for paused leads
- [ ] Transcript logs are visible to both Master and Tenant Admin

## Deployment

### Manus Hosting (Built-in)

The application is deployed automatically to Manus hosting:

1. **Create Checkpoint**: Save project state via Management UI
2. **Publish**: Click "Publish" button in Management UI
3. **Live URL**: Application is deployed to `https://your-project.manus.space`

### Custom Hosting (Vercel, Railway, etc.)

**Note**: Manus provides built-in hosting with custom domain support. External hosting may have compatibility issues.

If deploying elsewhere:

```bash
# Build
pnpm build

# Deploy dist/ folder to your hosting provider
# Ensure DATABASE_URL and all environment variables are set
```

## Troubleshooting

### Database Connection Issues

```bash
# Check DATABASE_URL is set correctly
echo $DATABASE_URL

# Verify migrations applied
pnpm db:push
```

### Webhook Not Receiving Events

- Verify endpoint is publicly accessible
- Check webhook signature verification is enabled
- Confirm `WEBHOOK_VERIFY_TOKEN` is set
- Review webhook logs in Stripe Dashboard or Meta Developers

### Stripe Checkout Not Opening

- Verify `STRIPE_PUBLISHABLE_KEY` is set
- Check Stripe test mode is active
- Ensure price ID is configured in `server/stripe.ts`

### LLM Not Categorizing Leads

- Verify `BUILT_IN_FORGE_API_KEY` is set
- Check Gemini API quota and limits
- Review agent logs in console output

## Performance Optimization

### Database Indexing

All critical tables have indexes on:
- `tenantId` (multi-tenant isolation)
- `category` (lead filtering)
- `status` (lead status tracking)
- `createdAt` (time-based queries)

### Caching

- User auth state cached in session cookie
- Tenant data cached in memory for fast access
- Lead counts cached for dashboard metrics

### Async Processing

- Lead categorization runs asynchronously
- Webhook processing is non-blocking
- Agent execution logs are written asynchronously

## Security Considerations

### Multi-Tenant Isolation

- All queries filtered by `tenantId` at procedure level
- Row-level security enforced via context user
- Tenant Admin cannot access other tenants' data

### API Security

- OAuth 2.0 authentication required for all protected routes
- Webhook signatures verified using HMAC-SHA256
- All sensitive data encrypted in transit (HTTPS only)

### Data Protection

- Transcript logs contain full lead information
- Visibility controls limit access (Master Admin vs Tenant Admin)
- Sensitive fields (Stripe keys, API tokens) never logged

## Support & Documentation

For issues or questions:

1. Check logs: `tail -f .manus-logs/devserver.log`
2. Review error messages in browser console
3. Test webhook endpoints manually with curl
4. Verify all environment variables are set

## License

ASTRIflow is proprietary software. All rights reserved.
