import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, Building2, TrendingUp, Activity, LogOut, Plus, AlertTriangle, Clock } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import CreateTenantDialog from "@/components/CreateTenantDialog";
import TenantManagementPanel from "@/components/TenantManagementPanel";
import BackToTerminalButton from "@/components/BackToTerminalButton";

/**
 * Master Command Center: Compact one-page grid for Owner/Master Admin
 * High-density tiles with real-time metrics and unified tenant list
 */
export default function CommandCenter() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [showCreateTenant, setShowCreateTenant] = useState(false);
  const [selectedTenant, setSelectedTenant] = useState<number | null>(null);

  // Fetch all tenants
  const { data: tenants = [], isLoading: tenantsLoading, refetch: refetchTenants } = trpc.tenants.list.useQuery();

  // Fetch system alerts
  const { data: alerts = [] } = trpc.alerts.list.useQuery({ limit: 10 });

  // Calculate metrics
  const activeTenants = tenants.filter((t) => t.status === "active").length;
  const pausedTenants = tenants.filter((t) => t.status === "paused").length;
  const tombstonedTenants = tenants.filter((t) => t.status === "tombstone").length;
  const activeSubscriptions = tenants.filter((t) => t.subscriptionStatus === "active").length;
  const totalTenants = tenants.length;
  const criticalAlerts = alerts.filter((a) => a.severity === "critical").length;
  
  // Estimate AI uptime (based on active agents)
  const agentUptime = activeSubscriptions > 0 ? Math.round((activeSubscriptions / activeSubscriptions) * 100) : 0;

  // Estimate pending requests (paused leads + critical alerts)
  const pendingRequests = pausedTenants + criticalAlerts;

  // Mock monthly revenue (would come from Stripe in production)
  const monthlyRevenue = activeSubscriptions * 150;

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  if (user?.role !== "master_admin") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Card className="p-8 text-center">
          <AlertCircle className="mx-auto mb-4 h-12 w-12 text-destructive" />
          <h2 className="text-2xl font-bold text-foreground">Access Denied</h2>
          <p className="mt-2 text-muted-foreground">You do not have permission to access this page.</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <BackToTerminalButton className="absolute top-6 left-6" />
          <div>
            <h1 className="text-4xl font-bold text-foreground">Master Command Center</h1>
            <p className="mt-2 text-muted-foreground">System-wide oversight and real-time metrics</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => setShowCreateTenant(true)} className="bg-primary hover:bg-primary/90">
              <Plus className="mr-2 h-4 w-4" />
              Add Tenant
            </Button>
            <Button onClick={handleLogout} variant="outline" size="sm">
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>

        {/* High-Density Metrics Grid */}
        <div className="mb-8 grid grid-cols-1 gap-4 md:grid-cols-4">
          {/* Total Active Tenants */}
          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Tenants</p>
                <p className="text-3xl font-bold text-primary">{activeTenants}</p>
                <p className="mt-1 text-xs text-muted-foreground">{totalTenants} total</p>
              </div>
              <Building2 className="h-8 w-8 text-primary/50" />
            </div>
          </Card>

          {/* AI Agent Uptime */}
          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Agent Uptime</p>
                <p className="text-3xl font-bold text-secondary">{agentUptime}%</p>
                <p className="mt-1 text-xs text-muted-foreground">{activeSubscriptions} active</p>
              </div>
              <Activity className="h-8 w-8 text-secondary/50" />
            </div>
          </Card>

          {/* Pending Requests */}
          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending Requests</p>
                <p className="text-3xl font-bold text-accent">{pendingRequests}</p>
                <p className="mt-1 text-xs text-muted-foreground">{pausedTenants} paused</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-accent/50" />
            </div>
          </Card>

          {/* Monthly Revenue */}
          <Card className="border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Monthly Revenue</p>
                <p className="text-3xl font-bold text-success">${monthlyRevenue}</p>
                <p className="mt-1 text-xs text-muted-foreground">{activeSubscriptions} × $150</p>
              </div>
              <TrendingUp className="h-8 w-8 text-success/50" />
            </div>
          </Card>
        </div>

        {/* Unified Tenant List */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Main Tenant Table */}
          <div className="lg:col-span-2">
            <Card className="border-border bg-card p-6">
              <h2 className="mb-4 text-xl font-bold text-foreground">Tenant Overview</h2>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {tenantsLoading ? (
                  <p className="text-muted-foreground">Loading tenants...</p>
                ) : tenants.length === 0 ? (
                  <p className="text-muted-foreground">No tenants yet</p>
                ) : (
                  tenants.map((tenant) => (
                    <div
                      key={tenant.id}
                      onClick={() => setSelectedTenant(tenant.id)}
                      className={`flex items-center justify-between rounded border-l-4 p-4 cursor-pointer transition-colors ${
                        selectedTenant === tenant.id
                          ? "border-l-primary bg-primary/10"
                          : "border-l-muted hover:bg-muted/50"
                      }`}
                    >
                      <div className="flex-1">
                        <p className="font-semibold text-foreground">{tenant.name}</p>
                        <p className="text-xs text-muted-foreground">{tenant.email}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        {/* Lead Volume */}
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">Leads</p>
                          <p className="font-bold text-foreground">0</p>
                        </div>

                        {/* Bot Status Light */}
                        <div className="flex items-center gap-2">
                          <div
                            className={`h-3 w-3 rounded-full ${
                              tenant.status === "active" && tenant.agentEnabled
                                ? "bg-green-500"
                                : tenant.status === "paused"
                                ? "bg-yellow-500"
                                : tenant.status === "tombstone"
                                ? "bg-red-500"
                                : "bg-gray-500"
                            }`}
                          />
                          <span className="text-xs text-muted-foreground">
                            {tenant.status === "active" ? "Active" : tenant.status === "paused" ? "Paused" : "Tombstone"}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </Card>
          </div>

          {/* Management Panel */}
          <div>
            {selectedTenant ? (
              <TenantManagementPanel
                tenant={tenants.find((t) => t.id === selectedTenant)!}
                onRefresh={() => {
                  refetchTenants();
                  setSelectedTenant(null);
                }}
              />
            ) : (
              <Card className="border-border bg-card p-6 text-center">
                <Building2 className="mx-auto mb-4 h-12 w-12 text-muted-foreground/50" />
                <p className="text-muted-foreground">Select a tenant to manage</p>
              </Card>
            )}
          </div>
        </div>

        {/* Alerts Section */}
        {criticalAlerts > 0 && (
          <div className="mt-8">
            <Card className="border-border bg-card p-6">
              <h2 className="mb-4 text-xl font-bold text-foreground">Critical Alerts ({criticalAlerts})</h2>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {alerts
                  .filter((a) => a.severity === "critical")
                  .slice(0, 5)
                  .map((alert) => (
                    <div key={alert.id} className="rounded border-l-4 border-l-destructive bg-destructive/10 p-3">
                      <p className="text-sm font-semibold text-foreground">{alert.title}</p>
                      <p className="text-xs text-muted-foreground">{alert.message}</p>
                    </div>
                  ))}
              </div>
            </Card>
          </div>
        )}
      </div>

      {/* Create Tenant Dialog */}
      <CreateTenantDialog
        open={showCreateTenant}
        onOpenChange={setShowCreateTenant}
        onSuccess={() => {
          refetchTenants();
          setShowCreateTenant(false);
        }}
      />
    </div>
  );
}
