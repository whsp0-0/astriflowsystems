import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { AlertCircle, CheckCircle, LogOut, RefreshCw } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";
import { toast } from "sonner";
import BackToTerminalButton from "@/components/BackToTerminalButton";

/**
 * AdminDashboard: View for staff/employees (Admin role)
 * Shows Lead Review Queue for flagged leads requiring manual intervention
 * Cannot see revenue or owner financials
 */
export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [selectedLeadId, setSelectedLeadId] = useState<number | null>(null);
  const [editingData, setEditingData] = useState<Record<string, string>>({});

  // Fetch paused/flagged leads that need review
  const { data: pausedLeads = [], isLoading: leadsLoading, refetch } = trpc.leads.getPaused.useQuery();

  // Mutation to update lead data
  const updateLead = trpc.leads.update.useMutation();

  // Mutation to resolve a paused lead after manual review
  const approveLead = trpc.leads.resolvePaused.useMutation({
    onSuccess: () => {
      toast.success("Lead approved and moved to processing queue");
      setSelectedLeadId(null);
      setEditingData({});
      refetch();
    },
    onError: (err: any) => {
      toast.error(`Failed to approve lead: ${err.message}`);
    },
  });

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  const handleApprove = async (leadId: number) => {
    await approveLead.mutateAsync({ leadId, resolutionNotes: "Approved by admin after manual review" });
  };

  const handleUpdateAndApprove = async (leadId: number) => {
    // First, persist any edits
    if (Object.keys(editingData).length > 0) {
      try {
        await updateLead.mutateAsync({
          id: leadId,
          ...editingData,
        });
        toast.success("Lead data updated");
      } catch (err: any) {
        toast.error(`Failed to update lead: ${err.message}`);
        return;
      }
    }
    // Then approve the lead
    await handleApprove(leadId);
  };

  const selectedLead = pausedLeads.find((l: any) => l.id === selectedLeadId);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <BackToTerminalButton />
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Lead Review Queue</h1>
              <p className="text-xs text-muted-foreground mt-1">Admin Dashboard - {user?.name}</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-muted-foreground hover:text-foreground"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-7xl mx-auto">
          {/* Queue Stats */}
          <Card className="bg-card border border-border mb-8">
            <div className="p-6">
              <div className="flex items-center gap-4">
                <AlertCircle className="w-6 h-6 text-amber-500" />
                <div>
                  <h2 className="text-lg font-semibold text-foreground">Flagged Leads Requiring Review</h2>
                  <p className="text-sm text-muted-foreground mt-1">
                    {pausedLeads.length} lead{pausedLeads.length !== 1 ? "s" : ""} waiting for manual verification
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Two-Column Layout: Queue + Details */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left: Lead Queue */}
            <div className="lg:col-span-1">
              <Card className="bg-card border border-border">
                <div className="p-6">
                  <h3 className="text-sm font-semibold text-foreground mb-4">Queue</h3>
                  <div className="space-y-2">
                    {leadsLoading ? (
                      <p className="text-xs text-muted-foreground">Loading leads...</p>
                    ) : pausedLeads.length === 0 ? (
                      <p className="text-xs text-muted-foreground">No flagged leads at this time</p>
                    ) : (
                      pausedLeads.map((lead: any) => (
                        <button
                          key={lead.id}
                          onClick={() => {
                            setSelectedLeadId(lead.id);
                            setEditingData({});
                          }}
                          className={`w-full text-left p-3 border border-border rounded text-xs transition-colors ${
                            selectedLeadId === lead.id
                              ? "bg-accent text-accent-foreground"
                              : "bg-background hover:bg-muted text-foreground"
                          }`}
                        >
                          <div className="font-medium truncate">
                            {lead.contactName || "Unknown"}
                          </div>
                          <div className="text-muted-foreground truncate">
                            {lead.contactEmail || lead.contactPhone || "No contact"}
                          </div>
                        </button>
                      ))
                    )}
                  </div>
                </div>
              </Card>
            </div>

            {/* Right: Lead Details & Edit */}
            <div className="lg:col-span-2">
              {selectedLead ? (
                <Card className="bg-card border border-border">
                  <div className="p-6 space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold text-foreground mb-4">Lead Details</h3>
                      <div className="space-y-4">
                        {/* Name */}
                        <div>
                          <label className="text-xs font-medium text-muted-foreground">Contact Name</label>
                          <input
                            type="text"
                            defaultValue={selectedLead.name || ""}
                            onChange={(e) =>
                              setEditingData((prev) => ({
                                ...prev,
                                name: e.target.value,
                              }))
                            }
                            className="w-full mt-1 px-3 py-2 bg-background border border-border rounded text-foreground text-sm focus:outline-none focus:border-accent"
                          />
                        </div>

                        {/* Email */}
                        <div>
                          <label className="text-xs font-medium text-muted-foreground">Email</label>
                          <input
                            type="email"
                            defaultValue={selectedLead.email || ""}
                            onChange={(e) =>
                              setEditingData((prev) => ({
                                ...prev,
                                email: e.target.value,
                              }))
                            }
                            className="w-full mt-1 px-3 py-2 bg-background border border-border rounded text-foreground text-sm focus:outline-none focus:border-accent"
                          />
                        </div>

                        {/* Phone */}
                        <div>
                          <label className="text-xs font-medium text-muted-foreground">Phone</label>
                          <input
                            type="tel"
                            defaultValue={selectedLead.phone || ""}
                            onChange={(e) =>
                              setEditingData((prev) => ({
                                ...prev,
                                phone: e.target.value,
                              }))
                            }
                            className="w-full mt-1 px-3 py-2 bg-background border border-border rounded text-foreground text-sm focus:outline-none focus:border-accent"
                          />
                        </div>

                        {/* Message */}
                        <div>
                          <label className="text-xs font-medium text-muted-foreground">Message</label>
                          <textarea
                            defaultValue={selectedLead.message || ""}
                            onChange={(e) =>
                              setEditingData((prev) => ({
                                ...prev,
                                message: e.target.value,
                              }))
                            }
                            className="w-full mt-1 px-3 py-2 bg-background border border-border rounded text-foreground text-sm focus:outline-none focus:border-accent"
                            rows={3}
                          />
                        </div>

                        {/* Current Category */}
                        <div>
                          <label className="text-xs font-medium text-muted-foreground">Current Category</label>
                          <div className="mt-1 px-3 py-2 bg-muted border border-border rounded text-foreground text-sm">
                            {selectedLead.category || "Uncategorized"}
                          </div>
                        </div>

                        {/* Self-Correction Reason */}
                        <div>
                          <label className="text-xs font-medium text-muted-foreground">Flagged Reason</label>
                          <div className="mt-1 px-3 py-2 bg-muted border border-border rounded text-foreground text-sm">
                            {selectedLead.selfCorrectionReason || "No reason provided"}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-3 pt-4 border-t border-border">
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => handleUpdateAndApprove(selectedLead.id)}
                        disabled={approveLead.isPending}
                        className="flex-1"
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        {approveLead.isPending ? "Processing..." : "Approve & Process"}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => refetch()}
                        className="flex-1"
                      >
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Refresh
                      </Button>
                    </div>
                  </div>
                </Card>
              ) : (
                <Card className="bg-card border border-border">
                  <div className="p-6 text-center">
                    <p className="text-muted-foreground">Select a lead from the queue to review</p>
                  </div>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
