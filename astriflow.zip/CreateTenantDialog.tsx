import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

interface CreateTenantDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export default function CreateTenantDialog({ open, onOpenChange, onSuccess }: CreateTenantDialogProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
  });

  const generateLink = trpc.tenants.generateSubscriptionLink.useMutation();

  const createTenant = trpc.tenants.create.useMutation({
    onSuccess: async (data) => {
      // Generate subscription link
      const linkResult = await generateLink.mutateAsync({ tenantId: data.tenantId });
      
      toast.success(`Tenant "${formData.name}" created successfully!`);
      toast.success(`Subscription link generated. Opening checkout...`);
      
      // Open checkout in new tab
      window.open(linkResult.checkoutUrl, '_blank');
      
      setFormData({ name: "", email: "", phone: "", address: "", city: "", state: "", zipCode: "" });
      onOpenChange(false);
      onSuccess?.();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create tenant");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast.error("Business name is required");
      return;
    }
    createTenant.mutate(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-border bg-card sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-foreground">Add New HVAC Business</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Create a new tenant account for an HVAC company. This will automatically provision their database entries and
            generate a Stripe subscription link.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Business Name */}
          <div>
            <Label htmlFor="name" className="text-foreground">
              Business Name *
            </Label>
            <Input
              id="name"
              placeholder="e.g., Smith's HVAC Services"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="border-border bg-input text-foreground placeholder-muted-foreground"
              disabled={createTenant.isPending}
            />
          </div>

          {/* Email */}
          <div>
            <Label htmlFor="email" className="text-foreground">
              Email
            </Label>
            <Input
              id="email"
              type="email"
              placeholder="contact@hvacbusiness.com"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="border-border bg-input text-foreground placeholder-muted-foreground"
              disabled={createTenant.isPending}
            />
          </div>

          {/* Phone */}
          <div>
            <Label htmlFor="phone" className="text-foreground">
              Phone
            </Label>
            <Input
              id="phone"
              placeholder="+1 (555) 123-4567"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="border-border bg-input text-foreground placeholder-muted-foreground"
              disabled={createTenant.isPending}
            />
          </div>

          {/* Address */}
          <div>
            <Label htmlFor="address" className="text-foreground">
              Address
            </Label>
            <Input
              id="address"
              placeholder="123 Main St"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="border-border bg-input text-foreground placeholder-muted-foreground"
              disabled={createTenant.isPending}
            />
          </div>

          {/* City, State, Zip */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label htmlFor="city" className="text-foreground">
                City
              </Label>
              <Input
                id="city"
                placeholder="New York"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="border-border bg-input text-foreground placeholder-muted-foreground"
                disabled={createTenant.isPending}
              />
            </div>
            <div>
              <Label htmlFor="state" className="text-foreground">
                State
              </Label>
              <Input
                id="state"
                placeholder="NY"
                value={formData.state}
                onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                className="border-border bg-input text-foreground placeholder-muted-foreground"
                disabled={createTenant.isPending}
              />
            </div>
            <div>
              <Label htmlFor="zipCode" className="text-foreground">
                Zip Code
              </Label>
              <Input
                id="zipCode"
                placeholder="10001"
                value={formData.zipCode}
                onChange={(e) => setFormData({ ...formData, zipCode: e.target.value })}
                className="border-border bg-input text-foreground placeholder-muted-foreground"
                disabled={createTenant.isPending}
              />
            </div>
          </div>

          {/* Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={createTenant.isPending}
              className="flex-1 border-border text-foreground hover:bg-muted"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={createTenant.isPending || generateLink.isPending}
              className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              {createTenant.isPending || generateLink.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {generateLink.isPending ? "Generating link..." : "Creating..."}
                </>
              ) : (
                "Create Tenant & Generate Link"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
