import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Lock, X } from "lucide-react";
import { toast } from "sonner";
import { usePINSession } from "@/hooks/usePINSession";

interface PINPadLoginProps {
  onSuccess: () => void;
  correctPIN: string;
}

export default function PINPadLogin({ onSuccess, correctPIN }: PINPadLoginProps) {
  const [pin, setPin] = useState("");
  const [attempts, setAttempts] = useState(0);
  const [locked, setLocked] = useState(false);
  const { isVerified, setVerified } = usePINSession();

  // If session is already verified, call onSuccess immediately
  useEffect(() => {
    if (isVerified) {
      onSuccess();
    }
  }, [isVerified, onSuccess]);

  if (isVerified) {
    return null; // Session is valid, component will trigger onSuccess via useEffect
  }

  const handleDigit = (digit: string) => {
    if (locked || pin.length >= 4) return;
    setPin(pin + digit);
  };

  const handleBackspace = () => {
    if (locked) return;
    setPin(pin.slice(0, -1));
  };

  const handleSubmit = () => {
    if (pin === correctPIN) {
      toast.success("Access granted");
      setVerified(); // Store session with 12-hour expiration
      onSuccess();
      setPin("");
    } else {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      setPin("");
      
      if (newAttempts >= 3) {
        setLocked(true);
        toast.error("Too many failed attempts. Access locked for 5 minutes.");
        setTimeout(() => {
          setLocked(false);
          setAttempts(0);
        }, 5 * 60 * 1000);
      } else {
        toast.error(`Incorrect PIN. ${3 - newAttempts} attempts remaining.`);
      }
    }
  };

  const handleClear = () => {
    setPin("");
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <Card className="border-border bg-card w-full max-w-sm p-8">
        <div className="mb-6 flex items-center justify-center">
          <Lock className="h-12 w-12 text-primary" />
        </div>
        
        <h2 className="mb-2 text-center text-2xl font-bold text-foreground">
          Master Vault Access
        </h2>
        <p className="mb-6 text-center text-sm text-muted-foreground">
          Enter the 4-digit PIN to access the Master Dashboard
        </p>

        {locked && (
          <div className="mb-6 rounded-lg border border-destructive/30 bg-destructive/5 p-4">
            <p className="text-center text-sm text-destructive">
              Access locked due to too many failed attempts. Try again in 5 minutes.
            </p>
          </div>
        )}

        {/* PIN Display */}
        <div className="mb-8 flex justify-center gap-3">
          {[0, 1, 2, 3].map((i) => (
            <div
              key={i}
              className="flex h-12 w-12 items-center justify-center rounded-lg border-2 border-border bg-background font-bold text-foreground"
            >
              {pin[i] ? "•" : ""}
            </div>
          ))}
        </div>

        {/* PIN Pad */}
        <div className="mb-6 grid grid-cols-3 gap-2">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
            <Button
              key={digit}
              onClick={() => handleDigit(digit.toString())}
              disabled={locked || pin.length >= 4}
              variant="outline"
              className="h-12 text-lg font-semibold"
            >
              {digit}
            </Button>
          ))}
          
          {/* 0 Button - spans 2 columns */}
          <Button
            onClick={() => handleDigit("0")}
            disabled={locked || pin.length >= 4}
            variant="outline"
            className="col-span-2 h-12 text-lg font-semibold"
          >
            0
          </Button>

          {/* Backspace Button */}
          <Button
            onClick={handleBackspace}
            disabled={locked || pin.length === 0}
            variant="outline"
            className="h-12"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button
            onClick={handleClear}
            disabled={locked || pin.length === 0}
            variant="outline"
            className="flex-1"
          >
            Clear
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={locked || pin.length !== 4}
            className="flex-1 bg-primary hover:bg-primary/90"
          >
            Submit
          </Button>
        </div>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          {attempts > 0 && !locked && `${3 - attempts} attempts remaining`}
        </p>
      </Card>
    </div>
  );
}
