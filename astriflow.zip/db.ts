import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, leads, tenants, agentExecutionLogs, transcriptLogs, pausedLeads, systemAlerts } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'master_admin';
      updateSet.role = 'master_admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Multi-tenant query helpers
 */

// Get all tenants (Master Admin only)
export async function getAllTenants() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(tenants);
}

// Get tenant by ID
export async function getTenantById(tenantId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(tenants).where(eq(tenants.id, tenantId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Get all users in a tenant
export async function getTenantUsers(tenantId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).where(eq(users.tenantId, tenantId));
}

// Get leads for a tenant
export async function getTenantLeads(tenantId: number, limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(leads).where(eq(leads.tenantId, tenantId)).limit(limit).offset(offset);
}

// Get lead by ID with tenant isolation
export async function getLeadById(leadId: number, tenantId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(leads).where(and(eq(leads.id, leadId), eq(leads.tenantId, tenantId))).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Get agent execution logs for a lead
export async function getAgentExecutionLogs(leadId: number, tenantId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(agentExecutionLogs).where(and(eq(agentExecutionLogs.leadId, leadId), eq(agentExecutionLogs.tenantId, tenantId)));
}

// Get transcript log for a lead
export async function getTranscriptLog(leadId: number, tenantId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(transcriptLogs).where(and(eq(transcriptLogs.leadId, leadId), eq(transcriptLogs.tenantId, tenantId))).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Get paused leads for a tenant
export async function getPausedLeads(tenantId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(pausedLeads).where(eq(pausedLeads.tenantId, tenantId));
}

// Get system alerts
export async function getSystemAlerts(tenantId?: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  const query = tenantId ? db.select().from(systemAlerts).where(eq(systemAlerts.tenantId, tenantId)) : db.select().from(systemAlerts);
  return query.limit(limit);
}
