import { getDb } from "./db";
import { tenants, leads, agentExecutionLogs, systemAlerts } from "../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";
import { invokeLLM } from "./_core/llm";

/**
 * REPAIR SYSTEM - Hidden Auditor Agent
 * 
 * Scans all database connections and AI worker statuses.
 * Attempts auto-repair if glitches are detected.
 * Logs "Self-Healed" or "Manual Fix Required" alerts.
 */

export interface RepairSystemResult {
  success: boolean;
  issuesFound: string[];
  issuesFixed: string[];
  manualFixRequired: boolean;
  repairLog: string;
  timestamp: Date;
}

/**
 * Run the REPAIR SYSTEM diagnostic and auto-repair
 */
export async function runRepairSystem(): Promise<RepairSystemResult> {
  const db = await getDb();
  if (!db) {
    return {
      success: false,
      issuesFound: ["Database connection unavailable"],
      issuesFixed: [],
      manualFixRequired: true,
      repairLog: "Failed to connect to database",
      timestamp: new Date(),
    };
  }

  const issuesFound: string[] = [];
  const issuesFixed: string[] = [];
  let manualFixRequired = false;
  const repairLog: string[] = [];

  repairLog.push(`[${new Date().toISOString()}] REPAIR SYSTEM initiated`);

  try {
    // Check 1: Verify database connectivity
    repairLog.push("Checking database connectivity...");
    const tenantCount = await db.select().from(tenants).limit(1);
    repairLog.push(`✓ Database connectivity verified (${tenantCount.length} records accessible)`);

    // Check 2: Scan for orphaned leads (leads without valid tenant)
    repairLog.push("Scanning for orphaned leads...");
    const allLeads = await db.select().from(leads);
    const allTenants = await db.select().from(tenants);
    const tenantIds = new Set(allTenants.map((t) => t.id));

    const orphanedLeads = allLeads.filter((lead) => !tenantIds.has(lead.tenantId));
    if (orphanedLeads.length > 0) {
      issuesFound.push(`Found ${orphanedLeads.length} orphaned leads without valid tenant`);
      repairLog.push(`⚠ Found ${orphanedLeads.length} orphaned leads`);
      // Attempt auto-repair: archive orphaned leads
      try {
        for (const lead of orphanedLeads) {
          await db
            .update(leads)
            .set({ status: "archived" })
            .where(eq(leads.id, lead.id));
        }
        issuesFixed.push(`Archived ${orphanedLeads.length} orphaned leads`);
        repairLog.push(`✓ Auto-repaired: Archived ${orphanedLeads.length} orphaned leads`);
      } catch (err) {
        manualFixRequired = true;
        repairLog.push(`✗ Failed to auto-repair orphaned leads: ${err}`);
      }
    } else {
      repairLog.push("✓ No orphaned leads detected");
    }

    // Check 3: Verify agent execution logs integrity
    repairLog.push("Verifying agent execution logs...");
    const agentLogs = await db
      .select()
      .from(agentExecutionLogs)
      .orderBy(desc(agentExecutionLogs.createdAt))
      .limit(100);

    let corruptedLogs = 0;
    for (const log of agentLogs) {
      if (!log.tenantId || !log.leadId || !log.agentType) {
        corruptedLogs++;
      }
    }

    if (corruptedLogs > 0) {
      issuesFound.push(`Found ${corruptedLogs} corrupted agent execution logs`);
      repairLog.push(`⚠ Found ${corruptedLogs} corrupted logs`);
      manualFixRequired = true;
      repairLog.push(`✗ Manual review required for corrupted logs`);
    } else {
      repairLog.push("✓ Agent execution logs integrity verified");
    }

    // Check 4: Scan for stalled leads (pending > 24 hours)
    repairLog.push("Scanning for stalled leads...");
    const now = new Date();
    const twentyFourHoursAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    const stalledLeads = allLeads.filter(
      (lead) =>
        lead.status === "pending" &&
        lead.createdAt < twentyFourHoursAgo
    );

    if (stalledLeads.length > 0) {
      issuesFound.push(`Found ${stalledLeads.length} leads stalled in pending state > 24h`);
      repairLog.push(`⚠ Found ${stalledLeads.length} stalled leads`);
      // Attempt auto-repair: move stalled leads to processing
      try {
        for (const lead of stalledLeads) {
          await db
            .update(leads)
            .set({ status: "processing" })
            .where(eq(leads.id, lead.id));
        }
        issuesFixed.push(`Moved ${stalledLeads.length} stalled leads to processing`);
        repairLog.push(`✓ Auto-repaired: Moved ${stalledLeads.length} stalled leads to processing`);
      } catch (err) {
        manualFixRequired = true;
        repairLog.push(`✗ Failed to auto-repair stalled leads: ${err}`);
      }
    } else {
      repairLog.push("✓ No stalled leads detected");
    }

    // Check 5: Verify tenant subscription statuses
    repairLog.push("Verifying tenant subscription statuses...");
    const inactiveSubscriptions = allTenants.filter(
      (t) => t.subscriptionStatus === "canceled" || t.subscriptionStatus === "unpaid"
    );

    if (inactiveSubscriptions.length > 0) {
      repairLog.push(`ℹ Found ${inactiveSubscriptions.length} tenants with inactive subscriptions (expected)`);
      // Verify agents are disabled for these tenants
      for (const tenant of inactiveSubscriptions) {
        if (tenant.agentEnabled) {
          issuesFound.push(`Tenant ${tenant.id} has inactive subscription but agents still enabled`);
          repairLog.push(`⚠ Tenant ${tenant.id} has agents enabled despite inactive subscription`);
          // Auto-repair: disable agents
          try {
            await db
              .update(tenants)
              .set({ agentEnabled: false })
              .where(eq(tenants.id, tenant.id));
            issuesFixed.push(`Disabled agents for tenant ${tenant.id}`);
            repairLog.push(`✓ Auto-repaired: Disabled agents for tenant ${tenant.id}`);
          } catch (err) {
            manualFixRequired = true;
            repairLog.push(`✗ Failed to disable agents for tenant ${tenant.id}: ${err}`);
          }
        }
      }
    } else {
      repairLog.push("✓ All active tenants have valid subscriptions");
    }

    // Check 6: Use LLM to analyze system health
    repairLog.push("Running AI system health analysis...");
    const systemHealthAnalysis = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "You are a system health analyst. Analyze the provided system metrics and identify any anomalies or potential issues.",
        },
        {
          role: "user",
          content: `System Status Report:
- Total Tenants: ${allTenants.length}
- Total Leads: ${allLeads.length}
- Pending Leads: ${allLeads.filter((l) => l.status === "pending").length}
- Processing Leads: ${allLeads.filter((l) => l.status === "processing").length}
- Categorized Leads: ${allLeads.filter((l) => l.status === "categorized").length}
- Paused Leads: ${allLeads.filter((l) => l.status === "paused").length}
- Archived Leads: ${allLeads.filter((l) => l.status === "archived").length}
- Active Agents: ${allTenants.filter((t) => t.agentEnabled).length}
- Recent Agent Logs: ${agentLogs.length}

Provide a brief assessment of system health and any recommendations.`,
        },
      ],
    });

    const healthAnalysis = systemHealthAnalysis.choices[0]?.message.content || "No analysis available";
    repairLog.push(`AI Analysis: ${healthAnalysis}`);

    repairLog.push(`[${new Date().toISOString()}] REPAIR SYSTEM completed`);

    return {
      success: issuesFound.length === 0 || issuesFixed.length > 0,
      issuesFound,
      issuesFixed,
      manualFixRequired,
      repairLog: repairLog.join("\n"),
      timestamp: new Date(),
    };
  } catch (error) {
    repairLog.push(`✗ REPAIR SYSTEM error: ${error}`);
    return {
      success: false,
      issuesFound: [`System error: ${error}`],
      issuesFixed,
      manualFixRequired: true,
      repairLog: repairLog.join("\n"),
      timestamp: new Date(),
    };
  }
}

/**
 * Create a system alert for repair results
 */
export async function createRepairAlert(result: RepairSystemResult, masterAdminId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  const alertType = result.manualFixRequired ? "system_error" : "agent_failure";
  const title = result.manualFixRequired
    ? "🚨 REPAIR SYSTEM: Manual Fix Required"
    : "✅ REPAIR SYSTEM: Self-Healed";

  const message = `
Issues Found: ${result.issuesFound.length}
- ${result.issuesFound.join("\n- ") || "None"}

Issues Fixed: ${result.issuesFixed.length}
- ${result.issuesFixed.join("\n- ") || "None"}

${result.repairLog}
  `.trim();

  try {
    await db.insert(systemAlerts).values({
      tenantId: null,
      alertType,
      title,
      message,
      severity: result.manualFixRequired ? "critical" : "info",
      isRead: false,
      createdAt: result.timestamp,
    });
  } catch (err) {
    console.error("[RepairSystem] Failed to create alert:", err);
  }
}
