import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, Pause, X, Trash2 } from "lucide-react";
import { toast } from "sonner";

interface Tenant {
  id: number;
  name: string;
  email: string | null | undefined;
  subscriptionStatus: string | null;
  agentEnabled: boolean | null;
}

interface TenantManagementPanelProps {
  tenant: Tenant;
  onRefresh: () => void;
}

export default function TenantManagementPanel({ tenant, onRefresh }: TenantManagementPanelProps) {
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [showConfirmTerminate, setShowConfirmTerminate] = useState(false);

  const pauseMutation = trpc.tenants.pause.useMutation();
  const terminateMutation = trpc.tenants.terminate.useMutation();
  const deleteMutation = trpc.tenants.delete.useMutation();
  const restoreMutation = trpc.tenants.restore.useMutation();

  // Check if tenant is in tombstone status
  const isTombstoned = (tenant as any).status === "tombstone";
  const tombstonedAt = (tenant as any).tombstonedAt ? new Date((tenant as any).tombstonedAt) : null;
  const permanentDeleteAt = (tenant as any).permanentDeleteAt ? new Date((tenant as any).permanentDeleteAt) : null;
  const now = new Date();
  const hoursUntilPermanentDelete = permanentDeleteAt ? Math.ceil((permanentDeleteAt.getTime() - now.getTime()) / (1000 * 60 * 60)) : 0;
  const canRestore = isTombstoned && permanentDeleteAt && permanentDeleteAt > now;

  const handlePause = async () => {
    try {
      await pauseMutation.mutateAsync({ id: tenant.id });
      toast.success("Tenant paused. AI triage disabled.");
      onRefresh();
    } catch (error) {
      toast.error("Failed to pause tenant");
    }
  };

  const handleTerminate = async () => {
    try {
      await terminateMutation.mutateAsync({ id: tenant.id });
      toast.success("Tenant terminated. Subscription canceled.");
      setShowConfirmTerminate(false);
      onRefresh();
    } catch (error) {
      toast.error("Failed to terminate tenant");
    }
  };

  const handleDelete = async () => {
    try {
      await deleteMutation.mutateAsync({ id: tenant.id, confirmDelete: true });
      toast.success("Tenant moved to tombstone. Will be permanently deleted in 24 hours.");
      setShowConfirmDelete(false);
      onRefresh();
    } catch (error) {
      toast.error("Failed to delete tenant");
    }
  };

  const handleRestore = async () => {
    try {
      await restoreMutation.mutateAsync({ id: tenant.id });
      toast.success("Tenant restored successfully.");
      onRefresh();
    } catch (error) {
      toast.error("Failed to restore tenant");
    }
  };

  return (
    <div className="space-y-4">
      {/* Tenant Status Card */}
      <Card className="border-border bg-card p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-foreground">{tenant.name}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{tenant.email || "No email"}</p>
            <div className="mt-3 flex gap-2">
              <span
                className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-medium ${
                  tenant.subscriptionStatus === "active"
                    ? "bg-green-500/20 text-green-400"
                    : tenant.subscriptionStatus === "trialing"
                      ? "bg-blue-500/20 text-blue-400"
                      : "bg-red-500/20 text-red-400"
                }`}
              >
                {tenant.subscriptionStatus}
              </span>
              <span
                className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-medium ${
                  tenant.agentEnabled ? "bg-primary/20 text-primary" : "bg-muted/20 text-muted-foreground"
                }`}
              >
                {tenant.agentEnabled ? "Agents Enabled" : "Agents Disabled"}
              </span>
            </div>
          </div>
        </div>
      </Card>

      {/* Master Button Controls */}
      <Card className="border-border bg-card p-6">
        <h4 className="mb-4 font-semibold text-foreground">Master Controls</h4>
        <div className="space-y-3">
          {/* Pause Button */}
          <Button
            onClick={handlePause}
            disabled={pauseMutation.isPending || !tenant.agentEnabled}
            variant="outline"
            className="w-full justify-start"
          >
            <Pause className="mr-2 h-4 w-4" />
            {tenant.agentEnabled ? "Pause AI Triage" : "Already Paused"}
          </Button>

          {/* Terminate Button */}
          {!showConfirmTerminate ? (
            <Button
              onClick={() => setShowConfirmTerminate(true)}
              disabled={terminateMutation.isPending}
              variant="outline"
              className="w-full justify-start text-yellow-600 hover:text-yellow-700"
            >
              <X className="mr-2 h-4 w-4" />
              Terminate Tenant
            </Button>
          ) : (
            <div className="space-y-2 rounded-lg border border-yellow-500/30 bg-yellow-500/5 p-4">
              <p className="text-sm font-medium text-foreground">Confirm termination?</p>
              <p className="text-xs text-muted-foreground">This will cancel billing and revoke access.</p>
              <div className="flex gap-2">
                <Button
                  onClick={handleTerminate}
                  disabled={terminateMutation.isPending}
                  size="sm"
                  className="flex-1 bg-yellow-600 hover:bg-yellow-700"
                >
                  Confirm
                </Button>
                <Button
                  onClick={() => setShowConfirmTerminate(false)}
                  disabled={terminateMutation.isPending}
                  size="sm"
                  variant="outline"
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}

          {/* Delete Button */}
          {!showConfirmDelete ? (
            <Button
              onClick={() => setShowConfirmDelete(true)}
              disabled={deleteMutation.isPending}
              variant="outline"
              className="w-full justify-start text-destructive hover:text-destructive/90"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete Account
            </Button>
          ) : (
            <div className="space-y-2 rounded-lg border border-destructive/30 bg-destructive/5 p-4">
              <div className="flex gap-2">
                <AlertCircle className="h-5 w-5 flex-shrink-0 text-destructive" />
                <div>
                  <p className="text-sm font-medium text-foreground">Permanently delete tenant?</p>
                  <p className="text-xs text-muted-foreground">Tenant will be moved to tombstone status. You have 24 hours to restore.</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={handleDelete}
                  disabled={deleteMutation.isPending}
                  size="sm"
                  className="flex-1 bg-destructive hover:bg-destructive/90"
                >
                  Delete Permanently
                </Button>
                <Button
                  onClick={() => setShowConfirmDelete(false)}
                  disabled={deleteMutation.isPending}
                  size="sm"
                  variant="outline"
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Restore Button - Only visible during 24-hour tombstone window */}
      {canRestore && (
        <Card className="border-blue-500/30 bg-blue-500/5 p-6">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h4 className="font-semibold text-blue-400">Tenant in Tombstone Status</h4>
              <p className="mt-1 text-sm text-muted-foreground">
                This tenant will be permanently deleted in {hoursUntilPermanentDelete} hours.
              </p>
              {tombstonedAt && (
                <p className="mt-1 text-xs text-muted-foreground">
                  Deleted at: {tombstonedAt.toLocaleString()}
                </p>
              )}
            </div>
          </div>
          <Button
            onClick={handleRestore}
            disabled={restoreMutation.isPending}
            className="mt-4 w-full bg-blue-600 hover:bg-blue-700"
          >
            Restore Tenant
          </Button>
        </Card>
      )}
    </div>
  );
}
