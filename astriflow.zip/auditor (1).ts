import { router, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import { auditBotOutput, triggerAutoFix } from "../auditor";
import type { BotOutput } from "../auditor";

export const auditorRouter = router({
  /**
   * Audit a bot's output for validity and confidence
   */
  auditOutput: protectedProcedure
    .input(
      z.object({
        botName: z.enum(["triage", "billing", "communication"]),
        action: z.string(),
        reasoning: z.string(),
        output: z.string(),
        metadata: z.unknown().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const botOutput: BotOutput = {
        botName: input.botName,
        action: input.action,
        reasoning: input.reasoning,
        output: input.output,
        metadata: input.metadata as Record<string, unknown> | undefined,
      };

      const result = await auditBotOutput(botOutput);
      return result;
    }),

  /**
   * Trigger auto-fix for a failed audit
   */
  autoFix: protectedProcedure
    .input(
      z.object({
        botName: z.enum(["triage", "billing", "communication"]),
        action: z.string(),
        reasoning: z.string(),
        output: z.string(),
        errors: z.array(z.string()),
        suggestions: z.array(z.string()),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Only owner can trigger auto-fix
      if (ctx.user?.email !== "astriflowsystems@gmail.com") {
        throw new Error("Only owner can trigger auto-fix");
      }

      const botOutput: BotOutput = {
        botName: input.botName,
        action: input.action,
        reasoning: input.reasoning,
        output: input.output,
      };

      const auditResult = {
        botName: input.botName,
        confidence: 0,
        isValid: false,
        errors: input.errors,
        suggestions: input.suggestions,
        timestamp: new Date(),
        requiresHumanReview: true,
      };

      const fixedOutput = await triggerAutoFix(botOutput, auditResult);
      return fixedOutput;
    }),

  /**
   * Get audit history for a bot
   */
  getHistory: protectedProcedure
    .input(
      z.object({
        botName: z.enum(["triage", "billing", "communication"]).optional(),
        limit: z.number().default(10),
      })
    )
    .query(async ({ input, ctx }) => {
      // This would query audit logs from database
      // For now, return empty array
      return [];
    }),
});
