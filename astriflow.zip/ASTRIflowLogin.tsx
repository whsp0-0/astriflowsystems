import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { Zap, Users, TrendingUp, Shield, ArrowRight } from "lucide-react";

/**
 * ASTRIflow Branded Login Landing Page
 * Wraps Manus OAuth with ASTRIflow branding
 * Shows role selection for regular users
 * Auto-routes astriflowsystems@gmail.com to Owner Terminal
 */
export default function ASTRIflowLogin() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-950 via-purple-900 to-black">
      {/* Animated background grid */}
      <div className="absolute inset-0 opacity-10">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "linear-gradient(0deg, transparent 24%, rgba(0, 255, 255, .05) 25%, rgba(0, 255, 255, .05) 26%, transparent 27%, transparent 74%, rgba(0, 255, 255, .05) 75%, rgba(0, 255, 255, .05) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(0, 255, 255, .05) 25%, rgba(0, 255, 255, .05) 26%, transparent 27%, transparent 74%, rgba(0, 255, 255, .05) 75%, rgba(0, 255, 255, .05) 76%, transparent 77%, transparent)",
            backgroundSize: "50px 50px",
          }}
        ></div>
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-12">
        <div className="max-w-2xl w-full">
          {/* Header Section */}
          <div className="text-center mb-12">
            <div className="inline-block mb-6">
              <div className="flex items-center gap-2 text-cyan-400 font-mono text-sm mb-3">
                <Zap className="w-5 h-5" />
                <span>ASTRIFLOW OPERATIONS</span>
              </div>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400">
              Welcome to ASTRIflow
            </h1>
            <p className="text-lg text-purple-300 font-mono">
              Zero-Touch HVAC Lead Automation Platform
            </p>
          </div>

          {/* Feature Highlights */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
            <div className="bg-gradient-to-br from-purple-900/50 to-purple-950/50 border border-cyan-400/30 rounded-lg p-4 backdrop-blur">
              <Users className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
              <p className="text-sm text-cyan-300 font-mono text-center">Multi-Tenant</p>
              <p className="text-xs text-purple-300 mt-1 text-center">Secure data isolation</p>
            </div>
            <div className="bg-gradient-to-br from-purple-900/50 to-purple-950/50 border border-cyan-400/30 rounded-lg p-4 backdrop-blur">
              <Zap className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
              <p className="text-sm text-cyan-300 font-mono text-center">AI Agents</p>
              <p className="text-xs text-purple-300 mt-1 text-center">Self-healing network</p>
            </div>
            <div className="bg-gradient-to-br from-purple-900/50 to-purple-950/50 border border-cyan-400/30 rounded-lg p-4 backdrop-blur">
              <TrendingUp className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
              <p className="text-sm text-cyan-300 font-mono text-center">Real-Time</p>
              <p className="text-xs text-purple-300 mt-1 text-center">Live lead pipeline</p>
            </div>
          </div>

          {/* Login Card */}
          <Card className="bg-gradient-to-br from-purple-900/80 to-purple-950/80 border border-cyan-400/30 backdrop-blur-xl p-8">
            <div className="space-y-6">
              {/* Login Title */}
              <div className="text-center">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <Shield className="w-5 h-5 text-cyan-400" />
                  <h2 className="text-xl font-semibold text-cyan-300">Secure Access</h2>
                </div>
                <p className="text-sm text-purple-300">
                  Sign in with your ASTRIflow account
                </p>
              </div>

              {/* Login Button */}
              <div className="space-y-3">
                <a href={getLoginUrl()} className="block">
                  <Button
                    size="lg"
                    className="w-full bg-gradient-to-r from-cyan-400 to-blue-400 text-black hover:from-cyan-300 hover:to-blue-300 font-bold text-lg py-6 rounded-lg shadow-lg shadow-cyan-400/50 transition-all hover:shadow-cyan-400/75"
                  >
                    <span className="flex items-center justify-center gap-2">
                      Sign In with Manus OAuth
                      <ArrowRight className="w-5 h-5" />
                    </span>
                  </Button>
                </a>
                <p className="text-xs text-purple-400 font-mono text-center">
                  Powered by Manus Secure Authentication
                </p>
              </div>

              {/* Info Box */}
              <div className="bg-purple-900/50 border border-purple-700/50 rounded-lg p-4 space-y-2">
                <p className="text-xs text-purple-300 font-mono">
                  <span className="text-cyan-400">→</span> Owner: Direct access to Master Terminal
                </p>
                <p className="text-xs text-purple-300 font-mono">
                  <span className="text-cyan-400">→</span> Staff: Lead triage & operations
                </p>
                <p className="text-xs text-purple-300 font-mono">
                  <span className="text-cyan-400">→</span> Tenant: Client dashboard & leads
                </p>
              </div>

              {/* Security Notice */}
              <div className="border-t border-purple-700/50 pt-4">
                <p className="text-xs text-purple-400 text-center">
                  Your data is encrypted and secured by Manus OAuth
                </p>
              </div>
            </div>
          </Card>

          {/* Footer */}
          <div className="text-center mt-8">
            <p className="text-xs text-purple-400 font-mono">
              ASTRIflow v1.0 • Zero-Touch HVAC Lead Automation
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
