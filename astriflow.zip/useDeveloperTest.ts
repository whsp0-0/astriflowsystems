import { useEffect } from "react";
import { trpc } from "@/lib/trpc";

/**
 * Hook to enable Developer Test simulator
 * Keyboard shortcut: Ctrl+Shift+T to simulate incoming lead
 */
export function useDeveloperTest() {
  const processLead = trpc.leads.processLead.useMutation();

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      // Ctrl+Shift+T
      if (e.ctrlKey && e.shiftKey && e.key === "T") {
        e.preventDefault();
        // For now, process lead ID 1 as test
        processLead.mutate({ id: 1 });
      }
    };

    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, [processLead]);

  return {
    simulateLead: () => processLead.mutate({ id: 1 }),
    isLoading: processLead.isPending,
  };
}
