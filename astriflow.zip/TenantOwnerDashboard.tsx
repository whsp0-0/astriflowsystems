
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { trpc } from "@/lib/trpc";
import { AlertCircle, BarChart3, LogOut, Power } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";
import HibernationModeAlert from "@/components/HibernationModeAlert";
import { useAuth } from "@/_core/hooks/useAuth";

/**
 * TenantOwnerDashboard: View for HVAC company owners (Tenant Admin)
 * Shows only their specific leads, revenue stats, and AI Triage toggle
 */
export default function TenantOwnerDashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [aiTriageEnabled, setAiTriageEnabled] = useState(true);

  // Fetch tenant-specific leads
  const { data: leads = [], isLoading: leadsLoading } = trpc.leads.list.useQuery();

  // Fetch tenant info for subscription status
  const { data: tenantInfo } = trpc.tenants.list.useQuery();
  const currentTenant = tenantInfo?.[0];

  // Mock stats for now
  const stats = {
    totalLeads: leads.length,
    subscriptionStatus: currentTenant?.subscriptionStatus || "active",
    nextBillingDate: "2026-05-14",
    emergencyCount: leads.filter(l => l.category === "emergency").length,
    followUpCount: leads.filter(l => l.category === "follow_up").length,
    spamCount: leads.filter(l => l.category === "spam").length,
  };

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-foreground">
                {user?.name}
              </h1>
              <p className="text-xs text-muted-foreground mt-1">Tenant Owner Dashboard</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-muted-foreground hover:text-foreground"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-6xl mx-auto space-y-8">
          {/* Hibernation Mode Alert */}
          <HibernationModeAlert subscriptionStatus={stats.subscriptionStatus} />

          {/* AI Triage Control */}
          <Card className="bg-card border border-border">
            <div className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Power className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <h2 className="text-lg font-semibold text-foreground">AI Triage System</h2>
                    <p className="text-sm text-muted-foreground mt-1">
                      Enable or disable automatic lead categorization
                    </p>
                  </div>
                </div>
                <Switch
                  checked={aiTriageEnabled}
                  onCheckedChange={setAiTriageEnabled}
                  className="data-[state=checked]:bg-primary"
                />
              </div>
              <div className="mt-4 text-sm text-muted-foreground">
                Status: <span className="text-foreground font-medium">
                  {aiTriageEnabled ? "✓ Active" : "✗ Disabled"}
                </span>
              </div>
            </div>
          </Card>

          {/* Revenue Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-card border border-border">
              <div className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Leads</p>
                    <p className="text-3xl font-semibold text-foreground mt-2">
                      {stats?.totalLeads || 0}
                    </p>
                  </div>
                  <BarChart3 className="w-8 h-8 text-muted-foreground" />
                </div>
              </div>
            </Card>

            <Card className="bg-card border border-border">
              <div className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Subscription Status</p>
                    <p className="text-lg font-semibold text-foreground mt-2">
                      {stats?.subscriptionStatus || "Active"}
                    </p>
                  </div>
                  <AlertCircle className="w-8 h-8 text-muted-foreground" />
                </div>
              </div>
            </Card>

            <Card className="bg-card border border-border">
              <div className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Next Billing</p>
                    <p className="text-lg font-semibold text-foreground mt-2">
                      {stats?.nextBillingDate || "—"}
                    </p>
                  </div>
                  <BarChart3 className="w-8 h-8 text-muted-foreground" />
                </div>
              </div>
            </Card>
          </div>

          {/* Lead Categorization Summary */}
          <Card className="bg-card border border-border">
            <div className="p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">Lead Summary</h2>
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-background rounded-sm border border-border">
                  <p className="text-sm text-muted-foreground">Emergency</p>
                  <p className="text-2xl font-semibold text-foreground mt-2">
                    {stats?.emergencyCount || 0}
                  </p>
                </div>
                <div className="p-4 bg-background rounded-sm border border-border">
                  <p className="text-sm text-muted-foreground">Follow-up</p>
                  <p className="text-2xl font-semibold text-foreground mt-2">
                    {stats?.followUpCount || 0}
                  </p>
                </div>
                <div className="p-4 bg-background rounded-sm border border-border">
                  <p className="text-sm text-muted-foreground">Spam</p>
                  <p className="text-2xl font-semibold text-foreground mt-2">
                    {stats?.spamCount || 0}
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Recent Leads */}
          <Card className="bg-card border border-border">
            <div className="p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">Recent Leads</h2>
              {leadsLoading ? (
                <p className="text-muted-foreground">Loading leads...</p>
              ) : leads && leads.length > 0 ? (
                <div className="space-y-3">
                  {leads.slice(0, 5).map((lead: any) => (
                    <div
                      key={lead.id}
                      className="p-4 bg-background rounded-sm border border-border flex items-center justify-between"
                    >
                      <div>
                        <p className="font-medium text-foreground">{lead.name}</p>
                        <p className="text-sm text-muted-foreground">{lead.email}</p>
                      </div>
                      <span className="px-3 py-1 rounded-sm bg-card border border-border text-sm font-medium text-foreground">
                        {lead.category === "follow_up" ? "Follow-up" : lead.category?.charAt(0).toUpperCase() + lead.category?.slice(1)}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">No leads yet</p>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
