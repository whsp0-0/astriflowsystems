import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  decimal,
  json,
  index,
  foreignKey,
} from "drizzle-orm/mysql-core";

/**
 * MULTI-TENANT DATABASE SCHEMA FOR ASTRIFLOW
 *
 * Architecture:
 * - Master Admin: has access to all tenants and system-level operations
 * - Tenant Admin: has access to their specific tenant's data only
 * - Tenant User: has limited access within their tenant
 *
 * Row-level security is enforced at the procedure level via ctx.user.tenantId
 */

/**
 * Core user table with role-based access control
 */
export const users = mysqlTable(
  "users",
  {
    id: int("id").autoincrement().primaryKey(),
    openId: varchar("openId", { length: 64 }).notNull().unique(),
    name: text("name"),
    email: varchar("email", { length: 320 }),
    loginMethod: varchar("loginMethod", { length: 64 }),
    // Role: master_admin (system-wide), tenant_admin (per-tenant), tenant_user (limited)
    role: mysqlEnum("role", ["master_admin", "tenant_admin", "tenant_user"]).default("tenant_user").notNull(),
    // Tenant ID: null for master_admin, set for tenant_admin and tenant_user
    tenantId: int("tenantId"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
    lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  },
  (table) => [
    index("idx_users_tenantId").on(table.tenantId),
    index("idx_users_role").on(table.role),
  ]
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Tenants table: represents each HVAC company (client)
 */
export const tenants = mysqlTable(
  "tenants",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 255 }).notNull(),
    email: varchar("email", { length: 320 }),
    phone: varchar("phone", { length: 20 }),
    // Stripe subscription details
    stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
    stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }),
    subscriptionStatus: mysqlEnum("subscriptionStatus", ["active", "trialing", "past_due", "canceled", "unpaid"]).default("trialing"),
    // Tenant metadata
    businessType: varchar("businessType", { length: 100 }).default("HVAC"),
    address: text("address"),
    city: varchar("city", { length: 100 }),
    state: varchar("state", { length: 50 }),
    zipCode: varchar("zipCode", { length: 20 }),
    // Agent configuration
    agentEnabled: boolean("agentEnabled").default(true),
    // Graceful deletion protocol
    status: mysqlEnum("status", ["active", "paused", "tombstone"]).default("active"),
    tombstonedAt: timestamp("tombstonedAt"), // When tenant was moved to tombstone
    permanentDeleteAt: timestamp("permanentDeleteAt"), // When to permanently delete (24h after tombstone)
    // Timestamps
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    index("idx_tenants_stripeCustomerId").on(table.stripeCustomerId),
    index("idx_tenants_subscriptionStatus").on(table.subscriptionStatus),
  ]
);

export type Tenant = typeof tenants.$inferSelect;
export type InsertTenant = typeof tenants.$inferInsert;

/**
 * Leads table: incoming leads from Instagram/DM or other sources
 */
export const leads = mysqlTable(
  "leads",
  {
    id: int("id").autoincrement().primaryKey(),
    tenantId: int("tenantId").notNull(),
    // Lead source and metadata
    sourceChannel: varchar("sourceChannel", { length: 50 }).default("instagram_dm"), // instagram_dm, webhook, etc.
    sourceId: varchar("sourceId", { length: 255 }), // External ID from source
    // Lead information
    name: varchar("name", { length: 255 }),
    email: varchar("email", { length: 320 }),
    phone: varchar("phone", { length: 20 }),
    message: text("message"),
    // Lead categorization (by Lead Worker Agent)
    category: mysqlEnum("category", ["emergency", "follow_up", "spam", "uncategorized"]).default("uncategorized"),
    categoryConfidence: decimal("categoryConfidence", { precision: 3, scale: 2 }), // 0.00 to 1.00
    // Categorization audit trail
    categoryReason: text("categoryReason"), // Explanation from LLM
    categoryAuditedAt: timestamp("categoryAuditedAt"),
    categoryAuditedBy: int("categoryAuditedBy"), // User ID of auditor
    // Self-Correction Loop tracking
    selfCorrectionTriggered: boolean("selfCorrectionTriggered").default(false),
    selfCorrectionReason: text("selfCorrectionReason"),
    selfCorrectionAttempts: int("selfCorrectionAttempts").default(0),
    // Status
    status: mysqlEnum("status", ["pending", "processing", "categorized", "paused", "archived"]).default("pending"),
    // Timestamps
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    index("idx_leads_tenantId").on(table.tenantId),
    index("idx_leads_category").on(table.category),
    index("idx_leads_status").on(table.status),
    index("idx_leads_createdAt").on(table.createdAt),
    foreignKey({
      columns: [table.tenantId],
      foreignColumns: [tenants.id],
    }),
  ]
);

export type Lead = typeof leads.$inferSelect;
export type InsertLead = typeof leads.$inferInsert;

/**
 * Agent Execution Logs: tracks every decision and action by agents
 */
export const agentExecutionLogs = mysqlTable(
  "agentExecutionLogs",
  {
    id: int("id").autoincrement().primaryKey(),
    tenantId: int("tenantId").notNull(),
    leadId: int("leadId").notNull(),
    // Agent identification
    agentType: mysqlEnum("agentType", ["lead_worker", "safety_critic", "master_auditor"]).notNull(),
    agentVersion: varchar("agentVersion", { length: 50 }).default("1.0"),
    // Execution details
    action: varchar("action", { length: 255 }).notNull(), // e.g., "categorize_lead", "audit_categorization", "trigger_self_correction"
    input: json("input"), // Input data to the agent
    output: json("output"), // Output/decision from the agent
    // Status and result
    status: mysqlEnum("status", ["success", "failure", "error"]).notNull(),
    errorMessage: text("errorMessage"),
    // Failure tracking for Master Auditor
    consecutiveFailureCount: int("consecutiveFailureCount").default(0),
    // Timestamps
    executedAt: timestamp("executedAt").defaultNow().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("idx_agentExecutionLogs_tenantId").on(table.tenantId),
    index("idx_agentExecutionLogs_leadId").on(table.leadId),
    index("idx_agentExecutionLogs_agentType").on(table.agentType),
    index("idx_agentExecutionLogs_status").on(table.status),
    foreignKey({
      columns: [table.tenantId],
      foreignColumns: [tenants.id],
    }),
    foreignKey({
      columns: [table.leadId],
      foreignColumns: [leads.id],
    }),
  ]
);

export type AgentExecutionLog = typeof agentExecutionLogs.$inferSelect;
export type InsertAgentExecutionLog = typeof agentExecutionLogs.$inferInsert;

/**
 * Transcript Logs: complete audit trail and proof of work for every lead
 */
export const transcriptLogs = mysqlTable(
  "transcriptLogs",
  {
    id: int("id").autoincrement().primaryKey(),
    tenantId: int("tenantId").notNull(),
    leadId: int("leadId").notNull(),
    // Transcript content
    transcript: text("transcript").notNull(), // Full markdown/text transcript
    // Categorization snapshot
    categoryAtSnapshot: varchar("categoryAtSnapshot", { length: 50 }),
    categoryReasonAtSnapshot: text("categoryReasonAtSnapshot"),
    // Self-Correction details
    selfCorrectionApplied: boolean("selfCorrectionApplied").default(false),
    selfCorrectionDetails: json("selfCorrectionDetails"),
    // Visibility and access control
    visibleToMasterAdmin: boolean("visibleToMasterAdmin").default(true),
    visibleToTenantAdmin: boolean("visibleToTenantAdmin").default(true),
    // Timestamps
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    index("idx_transcriptLogs_tenantId").on(table.tenantId),
    index("idx_transcriptLogs_leadId").on(table.leadId),
    foreignKey({
      columns: [table.tenantId],
      foreignColumns: [tenants.id],
    }),
    foreignKey({
      columns: [table.leadId],
      foreignColumns: [leads.id],
    }),
  ]
);

export type TranscriptLog = typeof transcriptLogs.$inferSelect;
export type InsertTranscriptLog = typeof transcriptLogs.$inferInsert;

/**
 * Paused Leads Queue: tracks leads paused by Master Auditor due to agent failures
 */
export const pausedLeads = mysqlTable(
  "pausedLeads",
  {
    id: int("id").autoincrement().primaryKey(),
    tenantId: int("tenantId").notNull(),
    leadId: int("leadId").notNull(),
    // Pause reason
    pauseReason: text("pauseReason").notNull(), // e.g., "Agent failure threshold exceeded"
    failingAgentType: varchar("failingAgentType", { length: 50 }).notNull(),
    consecutiveFailureCount: int("consecutiveFailureCount").notNull(),
    // Resolution
    resolvedAt: timestamp("resolvedAt"),
    resolvedBy: int("resolvedBy"), // User ID who resolved
    resolutionNotes: text("resolutionNotes"),
    // Timestamps
    pausedAt: timestamp("pausedAt").defaultNow().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("idx_pausedLeads_tenantId").on(table.tenantId),
    index("idx_pausedLeads_leadId").on(table.leadId),
    index("idx_pausedLeads_pausedAt").on(table.pausedAt),
    foreignKey({
      columns: [table.tenantId],
      foreignColumns: [tenants.id],
    }),
    foreignKey({
      columns: [table.leadId],
      foreignColumns: [leads.id],
    }),
  ]
);

export type PausedLead = typeof pausedLeads.$inferSelect;
export type InsertPausedLead = typeof pausedLeads.$inferInsert;

/**
 * System Alerts: notifications for Master Admin about critical events
 */
export const systemAlerts = mysqlTable(
  "systemAlerts",
  {
    id: int("id").autoincrement().primaryKey(),
    tenantId: int("tenantId"),
    // Alert details
    alertType: mysqlEnum("alertType", ["agent_failure", "subscription_issue", "lead_pause", "system_error"]).notNull(),
    title: varchar("title", { length: 255 }).notNull(),
    message: text("message").notNull(),
    // Related entities
    leadId: int("leadId"),
    relatedData: json("relatedData"),
    // Status
    severity: mysqlEnum("severity", ["info", "warning", "critical"]).default("warning"),
    isRead: boolean("isRead").default(false),
    // Timestamps
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("idx_systemAlerts_tenantId").on(table.tenantId),
    index("idx_systemAlerts_alertType").on(table.alertType),
    index("idx_systemAlerts_isRead").on(table.isRead),
    index("idx_systemAlerts_createdAt").on(table.createdAt),
  ]
);

export type SystemAlert = typeof systemAlerts.$inferSelect;
export type InsertSystemAlert = typeof systemAlerts.$inferInsert;
