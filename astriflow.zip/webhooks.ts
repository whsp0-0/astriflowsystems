import { getDb } from "./db";
import { leads, transcriptLogs } from "../drizzle/schema";
import { processLeadPipeline } from "./agents";
import { notifyOwner } from "./_core/notification";

/**
 * WEBHOOK HANDLER FOR INSTAGRAM/DM LEAD INGESTION
 * Receives incoming leads from Instagram DM and processes them through the agent pipeline
 */

export interface IncomingLeadPayload {
  tenantId: number;
  name?: string;
  email?: string;
  phone?: string;
  message: string;
  source: "instagram_dm" | "facebook_messenger" | "whatsapp" | "email" | "api";
  externalId?: string; // For deduplication
  timestamp?: number;
}

/**
 * Process incoming lead from webhook
 * This is the entry point for all lead ingestion
 */
export async function processIncomingLead(payload: IncomingLeadPayload): Promise<any> {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // Validate tenant exists
    const { tenants } = await import("../drizzle/schema");
    const { eq: eqImport } = await import("drizzle-orm");
    const tenantResult = await db.select().from(tenants).where(eqImport(tenants.id, payload.tenantId)).limit(1);

    if (tenantResult.length === 0) {
      throw new Error(`Tenant ${payload.tenantId} not found`);
    }

    const tenant = tenantResult[0];

    // Check subscription status for hibernation mode
    if (tenant.subscriptionStatus === "canceled" || tenant.subscriptionStatus === "unpaid") {
      console.log(`[Webhook] Tenant ${payload.tenantId} in hibernation mode (subscription: ${tenant.subscriptionStatus})`);
      return { success: false, error: "Tenant in hibernation mode - subscription inactive", hibernationMode: true };
    }

    // Check if agent is enabled for this tenant
    if (!tenant.agentEnabled) {
      console.log(`[Webhook] Agent disabled for tenant ${payload.tenantId}, skipping lead processing`);
      return { success: false, error: "Agent disabled for this tenant" };
    }

    // Create lead record
    const leadResult = await db.insert(leads).values({
      tenantId: payload.tenantId,
      sourceChannel: payload.source,
      sourceId: payload.externalId || undefined,
      name: payload.name || "Unknown",
      email: payload.email,
      phone: payload.phone,
      message: payload.message,
      status: "pending",
      category: "uncategorized",
      categoryReason: "Awaiting categorization",
      categoryAuditedAt: undefined,
      categoryAuditedBy: undefined,
      selfCorrectionTriggered: false,
      selfCorrectionReason: undefined,
      selfCorrectionAttempts: 0,
    });

    const leadId = (leadResult as any).insertId || 0;

    if (!leadId) {
      throw new Error("Failed to create lead record");
    }

    console.log(`[Webhook] Lead created: ${leadId} from ${payload.source}`);

    // Create initial transcript log entry
    await db.insert(transcriptLogs).values({
      leadId,
      tenantId: payload.tenantId,
      transcript: `Lead ingested from ${payload.source}\n\nPayload:\n${JSON.stringify(payload, null, 2)}`,
      categoryAtSnapshot: "uncategorized",
      categoryReasonAtSnapshot: "Awaiting categorization",
      selfCorrectionApplied: false,
      visibleToMasterAdmin: true,
      visibleToTenantAdmin: true,
    });

    // Process through agent pipeline
    const lead = {
      id: leadId,
      tenantId: payload.tenantId,
      sourceChannel: payload.source,
      sourceId: payload.externalId || null,
      name: payload.name || "Unknown",
      email: payload.email || null,
      phone: payload.phone || null,
      message: payload.message || null,
      status: "pending" as const,
      category: "uncategorized" as const,
      categoryReason: "Awaiting categorization",
      categoryConfidence: "0.00",
      categoryAuditedAt: null,
      categoryAuditedBy: null,
      selfCorrectionTriggered: false,
      selfCorrectionReason: null,
      selfCorrectionAttempts: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const pipelineResult = await processLeadPipeline(lead);

    if (pipelineResult.success) {
      console.log(`[Webhook] Lead ${leadId} categorized as: ${pipelineResult.data}`);

      // Notify owner of high-priority leads
      if (pipelineResult.data === "emergency") {
        await notifyOwner({
          title: "🚨 Emergency Lead Received",
          content: `New emergency lead from ${tenant.name}: ${payload.name || "Unknown"} - ${payload.phone || payload.email || "No contact"}`,
        });
      }

      return {
        success: true,
        leadId,
        category: pipelineResult.data,
      };
    } else {
      console.error(`[Webhook] Pipeline processing failed for lead ${leadId}:`, pipelineResult.error);

      // Log failure
      await db.insert(transcriptLogs).values({
        leadId,
        tenantId: payload.tenantId,
        transcript: `Pipeline processing error:\n\n${pipelineResult.error}`,
        categoryAtSnapshot: "uncategorized",
        categoryReasonAtSnapshot: `Error: ${pipelineResult.error}`,
        selfCorrectionApplied: false,
        visibleToMasterAdmin: true,
        visibleToTenantAdmin: false,
      });

      return {
        success: false,
        leadId,
        error: pipelineResult.error,
      };
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error("[Webhook] Error processing lead:", errorMessage);

    return {
      success: false,
      error: errorMessage,
    };
  }
}

/**
 * Verify webhook signature (for Instagram/Facebook webhooks)
 * This ensures the webhook is authentic
 */
export function verifyWebhookSignature(body: string, signature: string, secret: string): boolean {
  try {
    const crypto = require("crypto");
    const hash = crypto.createHmac("sha256", secret).update(body).digest("hex");
    return hash === signature;
  } catch (error) {
    console.error("[Webhook] Signature verification failed:", error);
    return false;
  }
}

/**
 * Handle webhook challenge (for Instagram/Facebook webhook setup)
 */
export function handleWebhookChallenge(mode: string, token: string, challenge: string): string | null {
  const verifyToken = process.env.WEBHOOK_VERIFY_TOKEN || "astriflow_verify_token";

  if (mode === "subscribe" && token === verifyToken) {
    console.log("[Webhook] Challenge verified");
    return challenge;
  }

  return null;
}
