import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import BackToTerminalButton from "@/components/BackToTerminalButton";

/**
 * Legal Page: Terms of Service and Legal Information
 * Accessible to all users (authenticated and unauthenticated)
 */
export default function Legal() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Legal Information</h1>
              <p className="text-xs text-muted-foreground mt-1">Terms of Service & Policies</p>
            </div>
            <BackToTerminalButton />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-3xl mx-auto space-y-8">
          {/* Terms of Service */}
          <Card className="bg-card border border-border">
            <div className="p-8 space-y-6">
              <div>
                <h2 className="text-xl font-semibold text-foreground mb-4">Terms of Service</h2>
                <p className="text-sm text-muted-foreground">Last Updated: April 14, 2026</p>
              </div>

              {/* Section 1: Free Trial */}
              <div className="space-y-3 border-t border-border pt-6">
                <h3 className="text-lg font-semibold text-foreground">1. Free Trial Period</h3>
                <p className="text-sm text-foreground leading-relaxed">
                  ASTRIflow offers a <strong>10-day free trial</strong> for all new customers. During this period, you have full access to all platform features at no cost. No payment information is required to start your trial. At the end of the trial period, your account will automatically transition to a paid subscription unless you cancel beforehand.
                </p>
              </div>

              {/* Section 2: Subscription Model */}
              <div className="space-y-3 border-t border-border pt-6">
                <h3 className="text-lg font-semibold text-foreground">2. Subscription Pricing</h3>
                <p className="text-sm text-foreground leading-relaxed">
                  After your free trial, ASTRIflow operates on a monthly subscription model. The standard subscription fee is <strong>$150 per month</strong> (USD). Billing occurs on the same day each month. You may cancel your subscription at any time, and your access will continue until the end of your current billing cycle.
                </p>
              </div>

              {/* Section 3: Support Channels */}
              <div className="space-y-3 border-t border-border pt-6">
                <h3 className="text-lg font-semibold text-foreground">3. Support & Assistance</h3>
                <p className="text-sm text-foreground leading-relaxed">
                  ASTRIflow provides technical support through the following channels:
                </p>
                <ul className="text-sm text-foreground space-y-2 ml-4">
                  <li>• <strong>Email Support:</strong> Support requests can be submitted via email and will be addressed within 24 business hours.</li>
                  <li>• <strong>AI Assistance:</strong> Built-in AI chatbot available within the platform for immediate help with common questions and troubleshooting.</li>
                </ul>
                <p className="text-sm text-foreground leading-relaxed mt-3">
                  <strong>Phone and video call support are not available.</strong> All support interactions are conducted asynchronously via email or through the AI assistance system to ensure efficiency and documentation of all issues.
                </p>
              </div>

              {/* Section 4: Liability Disclaimer */}
              <div className="space-y-3 border-t border-border pt-6">
                <h3 className="text-lg font-semibold text-foreground">4. Limitation of Liability</h3>
                <p className="text-sm text-foreground leading-relaxed">
                  <strong>ASTRIflow is not liable for final business decisions made by clients.</strong> The platform provides AI-powered lead categorization and analysis tools to assist with decision-making. However, all final business decisions, including lead prioritization, client outreach, and service delivery, remain the sole responsibility of the client. ASTRIflow makes no guarantees regarding the accuracy, completeness, or suitability of any recommendations provided by the platform.
                </p>
              </div>

              {/* Section 5: Data Privacy & Security */}
              <div className="space-y-3 border-t border-border pt-6">
                <h3 className="text-lg font-semibold text-foreground">5. Data Privacy & Security</h3>
                <p className="text-sm text-foreground leading-relaxed">
                  ASTRIflow implements industry-standard security measures to protect your data, including encryption in transit and at rest. Each tenant's data is isolated in a secure, multi-tenant database architecture. We do not share your lead data with third parties except as required by law or as explicitly authorized by you. For detailed information about how we collect, use, and protect your data, please refer to our Privacy Policy.
                </p>
              </div>

              {/* Section 6: Acceptable Use */}
              <div className="space-y-3 border-t border-border pt-6">
                <h3 className="text-lg font-semibold text-foreground">6. Acceptable Use Policy</h3>
                <p className="text-sm text-foreground leading-relaxed">
                  You agree to use ASTRIflow only for lawful purposes and in a way that does not infringe upon the rights of others or restrict their use and enjoyment of the platform. Prohibited behavior includes:
                </p>
                <ul className="text-sm text-foreground space-y-2 ml-4">
                  <li>• Attempting to gain unauthorized access to the platform or its systems</li>
                  <li>• Transmitting malware, viruses, or other harmful code</li>
                  <li>• Using the platform for spam, phishing, or fraudulent activities</li>
                  <li>• Reverse-engineering or attempting to extract proprietary algorithms</li>
                  <li>• Violating any applicable laws or regulations</li>
                </ul>
              </div>

              {/* Section 7: Intellectual Property */}
              <div className="space-y-3 border-t border-border pt-6">
                <h3 className="text-lg font-semibold text-foreground">7. Intellectual Property Rights</h3>
                <p className="text-sm text-foreground leading-relaxed">
                  All content, features, and functionality of ASTRIflow (including but not limited to software, algorithms, and documentation) are owned by ASTRIflow or its licensors and are protected by international copyright, trademark, and other intellectual property laws. You retain ownership of your lead data and business information. By using the platform, you grant ASTRIflow a limited license to process and analyze your data for the purpose of providing the service.
                </p>
              </div>

              {/* Section 8: Modifications to Terms */}
              <div className="space-y-3 border-t border-border pt-6">
                <h3 className="text-lg font-semibold text-foreground">8. Modifications to Terms</h3>
                <p className="text-sm text-foreground leading-relaxed">
                  ASTRIflow reserves the right to modify these Terms of Service at any time. Changes will be effective immediately upon posting to the platform. Your continued use of the platform following the posting of revised Terms means that you accept and agree to the changes. We encourage you to review these terms periodically.
                </p>
              </div>

              {/* Section 9: Termination */}
              <div className="space-y-3 border-t border-border pt-6">
                <h3 className="text-lg font-semibold text-foreground">9. Termination of Service</h3>
                <p className="text-sm text-foreground leading-relaxed">
                  ASTRIflow may terminate or suspend your account and access to the platform immediately, without prior notice or liability, if you violate any provision of these Terms of Service. Upon termination, your right to use the platform ceases immediately. You may request deletion of your account and associated data in accordance with our data retention policies.
                </p>
              </div>

              {/* Section 10: Contact Information */}
              <div className="space-y-3 border-t border-border pt-6">
                <h3 className="text-lg font-semibold text-foreground">10. Contact Us</h3>
                <p className="text-sm text-foreground leading-relaxed">
                  If you have any questions about these Terms of Service or need to report a violation, please contact us at:
                </p>
                <div className="bg-muted p-4 rounded border border-border mt-3">
                  <p className="text-sm text-foreground font-medium">ASTRIflow Support</p>
                  <p className="text-sm text-muted-foreground">Email: support@astriflow.com</p>
                  <p className="text-sm text-muted-foreground">Website: www.astriflow.com</p>
                </div>
              </div>

              {/* Acceptance */}
              <div className="space-y-3 border-t border-border pt-6">
                <p className="text-xs text-muted-foreground italic">
                  By accessing and using ASTRIflow, you acknowledge that you have read, understood, and agree to be bound by all the terms and conditions outlined in this Terms of Service agreement.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
