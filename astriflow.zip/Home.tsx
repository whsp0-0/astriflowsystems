import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { Zap, Users, TrendingUp, AlertCircle, ArrowRight } from "lucide-react";
import { useLocation } from "wouter";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-950 via-purple-900 to-black flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cyan-400"></div>
          <p className="text-cyan-400 mt-4 font-mono">Initializing ASTRIflow...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-950 via-purple-900 to-black">
        {/* Animated background grid */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: 'linear-gradient(0deg, transparent 24%, rgba(0, 255, 255, .05) 25%, rgba(0, 255, 255, .05) 26%, transparent 27%, transparent 74%, rgba(0, 255, 255, .05) 75%, rgba(0, 255, 255, .05) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(0, 255, 255, .05) 25%, rgba(0, 255, 255, .05) 26%, transparent 27%, transparent 74%, rgba(0, 255, 255, .05) 75%, rgba(0, 255, 255, .05) 76%, transparent 77%, transparent)',
            backgroundSize: '50px 50px'
          }}></div>
        </div>

        <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4">
          <div className="text-center max-w-2xl">
            {/* Logo/Title */}
            <div className="mb-8">
              <div className="inline-block mb-4">
                <div className="flex items-center gap-2 text-cyan-400 font-mono text-sm mb-2">
                  <Zap className="w-4 h-4" />
                  <span>ASTRIFLOW v1.0</span>
                </div>
              </div>
              <h1 className="text-5xl md:text-6xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400">
                Master Terminal
              </h1>
              <p className="text-lg text-purple-300 font-mono">
                Zero-Touch HVAC Lead Automation
              </p>
            </div>

            {/* Feature highlights */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12 mt-12">
              <div className="bg-gradient-to-br from-purple-900/50 to-purple-950/50 border border-cyan-400/30 rounded-lg p-4 backdrop-blur">
                <Users className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
                <p className="text-sm text-cyan-300 font-mono">Multi-Tenant</p>
                <p className="text-xs text-purple-300 mt-1">Secure data isolation</p>
              </div>
              <div className="bg-gradient-to-br from-purple-900/50 to-purple-950/50 border border-cyan-400/30 rounded-lg p-4 backdrop-blur">
                <Zap className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
                <p className="text-sm text-cyan-300 font-mono">AI Agents</p>
                <p className="text-xs text-purple-300 mt-1">Self-healing network</p>
              </div>
              <div className="bg-gradient-to-br from-purple-900/50 to-purple-950/50 border border-cyan-400/30 rounded-lg p-4 backdrop-blur">
                <TrendingUp className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
                <p className="text-sm text-cyan-300 font-mono">Real-Time</p>
                <p className="text-xs text-purple-300 mt-1">Live lead pipeline</p>
              </div>
            </div>

            {/* CTA */}
            <div className="space-y-4">
              <a href={getLoginUrl()} className="inline-block">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-cyan-400 to-blue-400 text-black hover:from-cyan-300 hover:to-blue-300 font-bold text-lg px-8 py-6 rounded-lg shadow-lg shadow-cyan-400/50 transition-all hover:shadow-cyan-400/75"
                >
                  <span className="flex items-center gap-2">
                    Access Master Terminal
                    <ArrowRight className="w-5 h-5" />
                  </span>
                </Button>
              </a>
              <p className="text-xs text-purple-400 font-mono">
                Secure OAuth login via Manus
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Authenticated view - Master Terminal
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="relative z-10 flex flex-col flex-1">
        {/* Header */}
        <div className="border-b border-border bg-card">
          <div className="px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-semibold text-foreground">
                  ASTRIflow
                </h1>
                <p className="text-xs text-muted-foreground mt-1">Master Terminal</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">{user?.name}</p>
                  <p className="text-xs text-muted-foreground">{user?.role}</p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={logout}
                  className="text-muted-foreground hover:text-foreground"
                >
                  Logout
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex flex-1 overflow-hidden">
          {/* Left Sidebar */}
          <div className="w-64 border-r border-border bg-card p-6 overflow-y-auto">
            <div className="space-y-2">
              {[
                { icon: Zap, label: "AI Agents" },
                { icon: Users, label: "Multi-Tenant" },
                { icon: TrendingUp, label: "Real-Time" },
                { icon: AlertCircle, label: "Self-Healing" },
              ].map((item, idx) => (
                <button
                  key={idx}
                  className="w-full flex items-center gap-3 px-4 py-2.5 rounded-sm border border-border bg-background text-foreground hover:bg-card transition-colors text-left text-sm font-medium"
                >
                  <item.icon className="w-4 h-4 flex-shrink-0 text-muted-foreground" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Right Main Content */}
          <div className="flex-1 p-8 overflow-y-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-4xl">
              {/* Quick Access Card */}
              <Card className="bg-card border border-border">
                <div className="p-6">
                  <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                    <Zap className="w-4 h-4 text-muted-foreground" />
                    Quick Actions
                  </h2>
                  <div className="space-y-2">
                    <Button
                      onClick={() => navigate("/master-admin")}
                      className="w-full bg-background border border-border text-foreground hover:bg-card justify-start font-medium text-sm"
                    >
                      <Users className="w-4 h-4 mr-2 text-muted-foreground" />
                      Master Admin Dashboard
                    </Button>
                    <Button
                      onClick={() => navigate("/tenant")}
                      className="w-full bg-background border border-border text-foreground hover:bg-card justify-start font-medium text-sm"
                    >
                      <TrendingUp className="w-4 h-4 mr-2 text-muted-foreground" />
                      Tenant Dashboard
                    </Button>
                  </div>
                </div>
              </Card>

              {/* System Status Card */}
              <Card className="bg-card border border-border">
                <div className="p-6">
                  <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-muted-foreground" />
                    System Status
                  </h2>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Agent Network</span>
                      <span className="text-green-600 font-medium">● ONLINE</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Database</span>
                      <span className="text-green-600 font-medium">● CONNECTED</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Webhooks</span>
                      <span className="text-green-600 font-medium">● ACTIVE</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Stripe Integration</span>
                      <span className="text-green-600 font-medium">● READY</span>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
