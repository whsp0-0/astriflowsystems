import { invokeLLM } from "./_core/llm";
import { getDb } from "./db";
import { leads, agentExecutionLogs, transcriptLogs, pausedLeads, systemAlerts } from "../drizzle/schema";
import type { Lead, InsertAgentExecutionLog, InsertTranscriptLog, InsertPausedLead, InsertSystemAlert } from "../drizzle/schema";

/**
 * ASTRIFLOW MULTI-AGENT ORCHESTRATION
 *
 * Architecture:
 * 1. Lead Worker Agent: Categorizes incoming leads using Gemini 1.5 Flash
 * 2. Safety Critic Agent: Audits every categorization and triggers self-correction
 * 3. Master Auditor Agent: Monitors failures and pauses leads after 2 consecutive failures
 *
 * Self-Correction Loop:
 * - Triggered when Safety Critic detects mismatch or missing phone number
 * - Lead Worker re-categorizes with additional context
 * - Safety Critic re-audits the corrected categorization
 */

type LeadCategory = "emergency" | "follow_up" | "spam" | "uncategorized";

interface CategorizationResult {
  category: LeadCategory;
  confidence: number;
  reason: string;
}

interface AgentExecutionResult {
  success: boolean;
  data?: unknown;
  error?: string;
  transcript?: string;
}

/**
 * LEAD WORKER AGENT
 * Categorizes incoming leads using Gemini 1.5 Flash
 */
export async function leadWorkerAgent(lead: Lead): Promise<AgentExecutionResult> {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // Build the lead context for LLM
    const leadContext = `
Lead Information:
- Name: ${lead.name || "Unknown"}
- Email: ${lead.email || "Not provided"}
- Phone: ${lead.phone || "Not provided"}
- Message: ${lead.message || "No message"}
- Source: ${lead.sourceChannel}

Categorize this HVAC lead into one of these categories:
1. EMERGENCY: Urgent issues like no heat in winter, AC failure in summer, safety hazards
2. FOLLOW_UP: Regular maintenance, quotes, non-urgent repairs
3. SPAM: Irrelevant messages, marketing, spam

Respond with JSON: { "category": "emergency|follow_up|spam", "confidence": 0.0-1.0, "reason": "explanation" }
`;

    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: "You are an HVAC lead categorization expert. Analyze leads and categorize them accurately. Always respond with valid JSON.",
        },
        {
          role: "user",
          content: leadContext,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "lead_categorization",
          strict: true,
          schema: {
            type: "object",
            properties: {
              category: { type: "string", enum: ["emergency", "follow_up", "spam"] },
              confidence: { type: "number", minimum: 0, maximum: 1 },
              reason: { type: "string" },
            },
            required: ["category", "confidence", "reason"],
            additionalProperties: false,
          },
        },
      },
    });

    const content = response.choices[0]?.message.content;
    if (!content) throw new Error("No response from LLM");

    const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
    const result = JSON.parse(contentStr) as CategorizationResult;

    // Log agent execution
    const executionLog: InsertAgentExecutionLog = {
      tenantId: lead.tenantId,
      leadId: lead.id,
      agentType: "lead_worker",
      agentVersion: "1.0",
      action: "categorize_lead",
      input: { leadId: lead.id, sourceChannel: lead.sourceChannel },
      output: result,
      status: "success",
      consecutiveFailureCount: 0,
    };

    await db.insert(agentExecutionLogs).values(executionLog);

    // Update lead with categorization
    await db.update(leads).set({
      category: result.category,
      categoryConfidence: result.confidence.toString() as any,
      categoryReason: result.reason,
      categoryAuditedAt: new Date(),
      status: "categorized",
    }).where({ id: lead.id } as any);

    return {
      success: true,
      data: result,
      transcript: `Lead Worker Agent categorized lead as "${result.category}" with ${(result.confidence * 100).toFixed(1)}% confidence. Reason: ${result.reason}`,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    return {
      success: false,
      error: errorMessage,
      transcript: `Lead Worker Agent failed: ${errorMessage}`,
    };
  }
}

/**
 * SAFETY CRITIC AGENT
 * Audits every categorization decision and triggers self-correction if needed
 */
export async function safetyCriticAgent(lead: Lead): Promise<AgentExecutionResult> {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // Check for issues that require self-correction
    const issues: string[] = [];

    if (!lead.phone) {
      issues.push("Missing phone number - cannot verify lead authenticity");
    }

    if (!lead.email) {
      issues.push("Missing email - incomplete contact information");
    }

    // For emergency leads, verify the categorization makes sense
    if (lead.category === "emergency") {
      const emergencyKeywords = ["heat", "ac", "cooling", "heating", "emergency", "urgent", "broken", "failure", "no"];
      const messageText = (lead.message || "").toLowerCase();
      const hasEmergencyKeywords = emergencyKeywords.some((kw) => messageText.includes(kw));

      const confidence = typeof lead.categoryConfidence === 'string' ? parseFloat(lead.categoryConfidence) : lead.categoryConfidence;
      if (!hasEmergencyKeywords && confidence && confidence < 0.7) {
        issues.push("Emergency categorization has low confidence and lacks emergency keywords");
      }
    }

    const needsSelfCorrection = issues.length > 0;

    // Log audit execution
    const auditLog: InsertAgentExecutionLog = {
      tenantId: lead.tenantId,
      leadId: lead.id,
      agentType: "safety_critic",
      agentVersion: "1.0",
      action: "audit_categorization",
      input: { leadId: lead.id, category: lead.category, issues },
      output: { needsSelfCorrection, issues },
      status: "success",
      consecutiveFailureCount: 0,
    };

    await db.insert(agentExecutionLogs).values(auditLog);

    if (needsSelfCorrection) {
      // Trigger self-correction loop
      await db.update(leads).set({
        selfCorrectionTriggered: true,
        selfCorrectionReason: issues.join("; "),
        selfCorrectionAttempts: (lead.selfCorrectionAttempts || 0) + 1,
        status: "processing",
      }).where({ id: lead.id } as any);

      return {
        success: true,
        data: { needsSelfCorrection: true, issues },
        transcript: `Safety Critic Agent detected issues: ${issues.join(", ")}. Triggering self-correction loop.`,
      };
    }

    return {
      success: true,
      data: { needsSelfCorrection: false },
      transcript: `Safety Critic Agent validated categorization. No issues detected.`,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    return {
      success: false,
      error: errorMessage,
      transcript: `Safety Critic Agent failed: ${errorMessage}`,
    };
  }
}

/**
 * SELF-CORRECTION LOOP
 * Re-categorizes lead with additional context when Safety Critic detects issues
 */
export async function selfCorrectionLoop(lead: Lead): Promise<AgentExecutionResult> {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // Re-categorize with additional context about issues
    const correctionContext = `
SELF-CORRECTION ATTEMPT #${lead.selfCorrectionAttempts}

Original Lead Information:
- Name: ${lead.name || "Unknown"}
- Email: ${lead.email || "Not provided"}
- Phone: ${lead.phone || "Not provided"}
- Message: ${lead.message || "No message"}

Previous Categorization: ${lead.category}
Reason for Re-evaluation: ${lead.selfCorrectionReason}

Please re-categorize this lead considering the issues above.
Respond with JSON: { "category": "emergency|follow_up|spam", "confidence": 0.0-1.0, "reason": "explanation" }
`;

    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: "You are an HVAC lead categorization expert performing quality assurance. Re-evaluate the lead categorization considering the flagged issues. Always respond with valid JSON.",
        },
        {
          role: "user",
          content: correctionContext,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "lead_recategorization",
          strict: true,
          schema: {
            type: "object",
            properties: {
              category: { type: "string", enum: ["emergency", "follow_up", "spam"] },
              confidence: { type: "number", minimum: 0, maximum: 1 },
              reason: { type: "string" },
            },
            required: ["category", "confidence", "reason"],
            additionalProperties: false,
          },
        },
      },
    });

    const content = response.choices[0]?.message.content;
    if (!content) throw new Error("No response from LLM");

    const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
    const result = JSON.parse(contentStr) as CategorizationResult;

    // Log self-correction execution
    const correctionLog: InsertAgentExecutionLog = {
      tenantId: lead.tenantId,
      leadId: lead.id,
      agentType: "lead_worker",
      agentVersion: "1.0",
      action: "self_correct_categorization",
      input: { leadId: lead.id, attemptNumber: lead.selfCorrectionAttempts },
      output: result,
      status: "success",
      consecutiveFailureCount: 0,
    };

    await db.insert(agentExecutionLogs).values(correctionLog);

    // Update lead with corrected categorization
    await db.update(leads).set({
      category: result.category,
      categoryConfidence: result.confidence.toString() as any,
      categoryReason: result.reason,
      status: "categorized",
    }).where({ id: lead.id } as any);

    return {
      success: true,
      data: result,
      transcript: `Self-Correction Loop: Lead re-categorized as "${result.category}" with ${(result.confidence * 100).toFixed(1)}% confidence. Reason: ${result.reason}`,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    return {
      success: false,
      error: errorMessage,
      transcript: `Self-Correction Loop failed: ${errorMessage}`,
    };
  }
}

/**
 * MASTER AUDITOR AGENT
 * Monitors all sub-agents and pauses leads after 2 consecutive failures
 */
export async function masterAuditorAgent(tenantId: number): Promise<AgentExecutionResult> {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    // Get recent agent execution logs for this tenant
    const recentLogs = await db.select().from(agentExecutionLogs)
      .where({ tenantId } as any)
      .orderBy(agentExecutionLogs.createdAt);

    // Track consecutive failures by agent type
    const failureTracking: Record<string, { count: number; leadId: number }> = {};

    for (const log of recentLogs) {
      const key = `${log.agentType}`;

      if (log.status === "failure" || log.status === "error") {
        if (!failureTracking[key]) {
          failureTracking[key] = { count: 0, leadId: log.leadId };
        }
        failureTracking[key].count += 1;

        // If 2 consecutive failures, pause the lead
        if (failureTracking[key].count >= 2) {
          const lead = await db.select().from(leads).where({ id: log.leadId } as any).limit(1);
          if (lead.length > 0) {
            // Create paused lead record
            const pausedLeadRecord: InsertPausedLead = {
              tenantId,
              leadId: log.leadId,
              pauseReason: `Agent failure threshold exceeded: ${log.agentType} failed ${failureTracking[key].count} times`,
              failingAgentType: log.agentType,
              consecutiveFailureCount: failureTracking[key].count,
            };

            await db.insert(pausedLeads).values(pausedLeadRecord);

            // Update lead status
            await db.update(leads).set({
              status: "paused",
            }).where({ id: log.leadId } as any);

            // Create system alert for Master Admin
            const alert: InsertSystemAlert = {
              tenantId,
              alertType: "agent_failure",
              title: `Critical: Lead Paused Due to Agent Failures`,
              message: `Lead #${log.leadId} has been paused. ${log.agentType} failed ${failureTracking[key].count} consecutive times. Manual review required.`,
              leadId: log.leadId,
              severity: "critical",
              relatedData: {
                agentType: log.agentType,
                failureCount: failureTracking[key].count,
              },
            };

            await db.insert(systemAlerts).values(alert);
          }

          // Reset counter after handling
          failureTracking[key].count = 0;
        }
      } else {
        // Success resets the counter
        failureTracking[key] = { count: 0, leadId: log.leadId };
      }
    }

    // Log audit execution
    const auditLog: InsertAgentExecutionLog = {
      tenantId,
      leadId: 0, // System-level audit
      agentType: "master_auditor",
      agentVersion: "1.0",
      action: "audit_agent_health",
      input: { tenantId },
      output: { failureTracking },
      status: "success",
      consecutiveFailureCount: 0,
    };

    await db.insert(agentExecutionLogs).values(auditLog);

    return {
      success: true,
      data: { failureTracking },
      transcript: `Master Auditor completed health check for tenant ${tenantId}. ${Object.keys(failureTracking).length} agents monitored.`,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    return {
      success: false,
      error: errorMessage,
      transcript: `Master Auditor failed: ${errorMessage}`,
    };
  }
}

/**
 * LEAD PROCESSING ORCHESTRATOR
 * Coordinates the full pipeline: Lead Worker -> Safety Critic -> Self-Correction (if needed) -> Transcript
 */
export async function processLeadPipeline(lead: Lead): Promise<AgentExecutionResult> {
  try {
    const db = await getDb();
    if (!db) throw new Error("Database connection failed");

    const transcriptLines: string[] = [];

    // Step 1: Lead Worker Agent
    const workerResult = await leadWorkerAgent(lead);
    if (!workerResult.success) {
      throw new Error(`Lead Worker failed: ${workerResult.error}`);
    }
    transcriptLines.push(workerResult.transcript || "");

    // Refresh lead data
    const updatedLead = await db.select().from(leads).where({ id: lead.id } as any).limit(1);
    if (updatedLead.length === 0) throw new Error("Lead not found after categorization");
    const leadAfterWorker = updatedLead[0];

    // Step 2: Safety Critic Agent
    const criticResult = await safetyCriticAgent(leadAfterWorker);
    if (!criticResult.success) {
      throw new Error(`Safety Critic failed: ${criticResult.error}`);
    }
    transcriptLines.push(criticResult.transcript || "");

    // Step 3: Self-Correction Loop (if needed)
    let finalLead = leadAfterWorker;
    const criticData = criticResult.data as any;
    if (criticData?.needsSelfCorrection) {
      const correctionResult = await selfCorrectionLoop(leadAfterWorker);
      if (!correctionResult.success) {
        throw new Error(`Self-Correction failed: ${correctionResult.error}`);
      }
      transcriptLines.push(correctionResult.transcript || "");

      // Refresh lead after correction
      const correctedLead = await db.select().from(leads).where({ id: lead.id } as any).limit(1);
      if (correctedLead.length > 0) {
        finalLead = correctedLead[0];
      }
    }

    // Step 4: Create Transcript Log
    const transcript: InsertTranscriptLog = {
      tenantId: lead.tenantId,
      leadId: lead.id,
      transcript: transcriptLines.join("\n\n"),
      categoryAtSnapshot: finalLead.category,
      categoryReasonAtSnapshot: finalLead.categoryReason,
      selfCorrectionApplied: finalLead.selfCorrectionTriggered,
      selfCorrectionDetails: {
        attempts: finalLead.selfCorrectionAttempts,
        reason: finalLead.selfCorrectionReason,
      },
      visibleToMasterAdmin: true,
      visibleToTenantAdmin: true,
    };

    await db.insert(transcriptLogs).values(transcript);

    // Step 5: Master Auditor (run asynchronously)
    setImmediate(() => masterAuditorAgent(lead.tenantId).catch(console.error));

    return {
      success: true,
      data: {
        leadId: lead.id,
        category: finalLead.category,
        selfCorrectionApplied: finalLead.selfCorrectionTriggered,
      },
      transcript: transcriptLines.join("\n\n"),
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    return {
      success: false,
      error: errorMessage,
      transcript: `Lead Processing Pipeline failed: ${errorMessage}`,
    };
  }
}
